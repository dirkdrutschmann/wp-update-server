<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\Resender;

class EmailResender
{
    private const PLUGIN_SLUG = 'cbadf-email-resender';
    private const TEXT_DOMAIN = 'cb-additional-features';

    public function __construct()
    {
        add_action('init', [$this, 'init']);
        add_action('admin_menu', [$this, 'add_admin_menu'], 25);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_cbadf_resend_emails', [$this, 'handle_ajax_resend']);
        add_filter('post_row_actions', [$this, 'add_resend_email_action'], 10, 2);
        add_action('wp_ajax_cbadf_resend_single_email', [$this, 'handle_single_email_resend']);
        add_action('admin_footer', [$this, 'add_inline_resend_script']);
    }

    public function init()
    {
        if (!class_exists('CommonsBooking\Repository\Booking')) {
            add_action('admin_notices', [$this, 'commonsbooking_missing_notice']);
        }
    }

    public function add_admin_menu()
    {
        add_submenu_page(
            'cbadf',
            __('CommonBooking E-Mail Resender', self::TEXT_DOMAIN),
            __('E-Mail Resender', self::TEXT_DOMAIN),
            'manage_options',
            self::PLUGIN_SLUG,
            [$this, 'admin_page']
        );
    }

    public function enqueue_admin_scripts($hook)
    {
        if (strpos($hook, self::PLUGIN_SLUG) === false) {
            return;
        }

        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('wp-jquery-ui-dialog');

        wp_add_inline_style('wp-admin', '
            .cb-resender-form { max-width: 800px; }
            .cb-resender-section {
                background: #fff;
                padding: 20px;
                margin: 20px 0;
                border: 1px solid #ccd0d4;
                border-radius: 4px;
            }
            .cb-resender-radio { margin: 10px 0; }
            .cb-resender-input { margin: 10px 0 20px 20px; }
            .cb-resender-input input, .cb-resender-input select {
                width: 300px;
                padding: 5px;
            }
            .cb-resender-results {
                background: #f9f9f9;
                border: 1px solid #ddd;
                padding: 15px;
                margin: 20px 0;
                border-radius: 4px;
                max-height: 400px;
                overflow-y: auto;
            }
            .cb-success { color: #46b450; }
            .cb-error { color: #dc3232; }
            .cb-warning { color: #ffb900; }
            .cb-loading {
                display: none;
                padding: 10px;
                text-align: center;
            }
            .cb-progress-bar {
                width: 100%;
                height: 20px;
                background-color: #f0f0f0;
                border-radius: 10px;
                overflow: hidden;
                margin: 10px 0;
            }
            .cb-progress-fill {
                height: 100%;
                background-color: #0073aa;
                width: 0%;
                transition: width 0.3s ease;
            }
        ');
    }

    public function admin_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('Sie haben keine Berechtigung fuer diese Seite.', self::TEXT_DOMAIN));
        }
        ?>
        <div class="wrap">
            <h1><?php _e('CommonBooking E-Mail Resender', self::TEXT_DOMAIN); ?></h1>

            <div class="cb-resender-section">
                <h2><?php _e('Buchungs-E-Mail erneut versenden', self::TEXT_DOMAIN); ?></h2>
                <p><?php _e('Geben Sie die Buchungs-ID ein, um die Bestaetigungs-E-Mail fuer diese Buchung erneut zu versenden:', self::TEXT_DOMAIN); ?></p>

                <form id="cb-resender-form" class="cb-resender-form">
                    <?php wp_nonce_field('cbadf_resend_emails', 'cbadf_resend_nonce'); ?>

                    <div class="cb-resender-input">
                        <label for="post_id"><strong><?php _e('Buchungs-ID:', self::TEXT_DOMAIN); ?></strong></label><br>
                        <input type="number" id="post_id" name="post_id" placeholder="z.B. 123" min="1" style="width: 200px;">
                        <p class="description"><?php _e('Geben Sie die ID einer spezifischen Buchung ein.', self::TEXT_DOMAIN); ?></p>
                    </div>

                    <p>
                        <button type="submit" class="button button-primary" id="cb-submit-btn">
                            <?php _e('E-Mail versenden', self::TEXT_DOMAIN); ?>
                        </button>
                    </p>
                </form>
            </div>

            <div id="cb-loading" class="cb-loading">
                <p><?php _e('Verarbeitung laeuft...', self::TEXT_DOMAIN); ?></p>
                <div class="cb-progress-bar">
                    <div class="cb-progress-fill" id="cb-progress-fill"></div>
                </div>
                <div id="cb-progress-text">0%</div>
            </div>

            <div id="cb-results" class="cb-resender-results" style="display: none;">
                <h3><?php _e('Ergebnisse', self::TEXT_DOMAIN); ?></h3>
                <div id="cb-results-content"></div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('#cb-resender-form').on('submit', function(e) {
                e.preventDefault();

                var formData = {
                    action: 'cbadf_resend_emails',
                    cbadf_resend_nonce: $('#cbadf_resend_nonce').val(),
                    resend_type: 'post_id',
                    post_id: $('#post_id').val()
                };

                if (!formData.post_id) {
                    alert('<?php _e('Bitte geben Sie eine Buchungs-ID ein.', self::TEXT_DOMAIN); ?>');
                    return;
                }

                $('#cb-loading').show();
                $('#cb-results').hide();
                $('#cb-submit-btn').prop('disabled', true);

                $.post(ajaxurl, formData)
                    .done(function(response) {
                        if (response.success) {
                            $('#cb-results-content').html(response.data.html);
                            $('#cb-results').show();
                        } else {
                            $('#cb-results-content').html('<div class="cb-error"><strong><?php _e('Fehler:', self::TEXT_DOMAIN); ?></strong> ' + response.data + '</div>');
                            $('#cb-results').show();
                        }
                    })
                    .fail(function(xhr, status, error) {
                        $('#cb-results-content').html('<div class="cb-error"><strong><?php _e('AJAX Fehler:', self::TEXT_DOMAIN); ?></strong> ' + error + '</div>');
                        $('#cb-results').show();
                    })
                    .always(function() {
                        $('#cb-loading').hide();
                        $('#cb-submit-btn').prop('disabled', false);
                    });
            });
        });
        </script>
        <?php
    }

    public function handle_ajax_resend()
    {
        if (!check_ajax_referer('cbadf_resend_emails', 'cbadf_resend_nonce', false)) {
            wp_send_json_error(__('Sicherheitspruefung fehlgeschlagen.', self::TEXT_DOMAIN));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Keine Berechtigung.', self::TEXT_DOMAIN));
        }

        if (!class_exists('CommonsBooking\Repository\Booking')) {
            wp_send_json_error(__('CommonBooking Plugin ist nicht aktiv.', self::TEXT_DOMAIN));
        }

        $resend_type = isset($_POST['resend_type']) ? sanitize_text_field($_POST['resend_type']) : '';
        $is_preview = ($resend_type === 'preview');

        try {
            $bookings = [];
            $html_output = '';

            switch ($resend_type) {
                case 'post_id':
                    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
                    if ($post_id <= 0) {
                        wp_send_json_error(__('Bitte geben Sie eine gueltige Buchungs-ID an.', self::TEXT_DOMAIN));
                    }

                    $booking = \CommonsBooking\Repository\Booking::getPostById($post_id);

                    if (!$booking || get_post_meta($post_id, 'type', true) !== '6') {
                        wp_send_json_error(__('Buchung mit dieser ID wurde nicht gefunden.', self::TEXT_DOMAIN));
                    }

                    $bookings = [$booking];
                    break;

                case 'date_range':
                case 'preview':
                    $start_date_key = ($resend_type === 'preview') ? 'preview_start_date' : 'start_date';
                    $start_date_str = isset($_POST[$start_date_key]) ? sanitize_text_field($_POST[$start_date_key]) : '';
                    $start_date = strtotime($start_date_str . ' 00:00:00');
                    $end_date = time();

                    if (!$start_date) {
                        wp_send_json_error(__('Ungueltiges Startdatum.', self::TEXT_DOMAIN));
                    }

                    $booking_status = isset($_POST['booking_status']) ? sanitize_text_field($_POST['booking_status']) : 'confirmed';
                    $status_filter = ($resend_type === 'date_range' && $booking_status === 'all')
                        ? ['confirmed', 'unconfirmed']
                        : ['confirmed'];

                    $bookings = \CommonsBooking\Repository\Booking::getByTimerange(
                        $start_date,
                        $end_date,
                        null,
                        null,
                        [],
                        $status_filter
                    );
                    break;

                default:
                    wp_send_json_error(__('Ungueltige Anfrage.', self::TEXT_DOMAIN));
            }

            if (empty($bookings)) {
                $html_output = '<div class="cb-warning"><strong>' . __('Keine Buchungen gefunden.', self::TEXT_DOMAIN) . '</strong></div>';
                wp_send_json_success(['html' => $html_output]);
            }

            $batch_size = isset($_POST['batch_size']) ? sanitize_text_field($_POST['batch_size']) : '10';
            if ($batch_size !== 'all' && !$is_preview && count($bookings) > intval($batch_size)) {
                $batch_size = intval($batch_size);
                $total_bookings = count($bookings);
                $bookings = array_slice($bookings, 0, $batch_size);

                $html_output .= '<div class="cb-warning">';
                $html_output .= '<h4>' . sprintf(__('Batch-Verarbeitung aktiv: %d von %d Buchungen werden verarbeitet', self::TEXT_DOMAIN), count($bookings), $total_bookings) . '</h4>';
                $html_output .= '<p>' . sprintf(__('Verbleibende Buchungen: %d', self::TEXT_DOMAIN), $total_bookings - $batch_size) . '</p>';
                $html_output .= '<p>' . __('Fuehren Sie das Plugin erneut aus, um weitere Buchungen zu verarbeiten.', self::TEXT_DOMAIN) . '</p>';
                $html_output .= '</div>';
            }

            $html_output .= '<div class="cb-summary">';
            $html_output .= '<h4>' . sprintf(__('Gefundene Buchungen: %d', self::TEXT_DOMAIN), count($bookings)) . '</h4>';

            if ($is_preview) {
                $html_output .= '<p class="cb-warning"><strong>' . __('VORSCHAU-MODUS: Keine E-Mails werden versendet!', self::TEXT_DOMAIN) . '</strong></p>';
            }

            $html_output .= '</div>';

            $success_count = 0;
            $error_count = 0;
            $errors = [];

            $html_output .= '<div class="cb-booking-list"><h4>' . __('Verarbeitete Buchungen:', self::TEXT_DOMAIN) . '</h4><ul>';

            foreach ($bookings as $booking) {
                try {
                    $booking_id = $booking->ID;
                    $user_data = $booking->getUserData();
                    $item = $booking->getItem();
                    $location = $booking->getLocation();
                    $start_date_formatted = date('d.m.Y H:i', $booking->getStartDate());
                    $end_date_formatted = date('d.m.Y H:i', $booking->getEndDate());
                    $status = $booking->getPost()->post_status;

                    $html_output .= '<li>';
                    $html_output .= '<strong>' . sprintf(__('Buchung #%d', self::TEXT_DOMAIN), $booking_id) . '</strong><br>';
                    $html_output .= sprintf(__('Benutzer: %s (%s)', self::TEXT_DOMAIN),
                        esc_html($user_data->display_name),
                        esc_html($user_data->user_email)) . '<br>';
                    $html_output .= sprintf(__('Gegenstand: %s', self::TEXT_DOMAIN), esc_html($item->post_title)) . '<br>';
                    $html_output .= sprintf(__('Standort: %s', self::TEXT_DOMAIN), esc_html($location->post_title)) . '<br>';
                    $html_output .= sprintf(__('Zeitraum: %s bis %s', self::TEXT_DOMAIN), $start_date_formatted, $end_date_formatted) . '<br>';
                    $html_output .= sprintf(__('Status: %s', self::TEXT_DOMAIN), esc_html($status)) . '<br>';

                    if (!$is_preview) {
                        try {
                            $booking_message = new \CommonsBooking\Messages\BookingMessage($booking_id, 'confirmed');
                            $booking_message->triggerMail();

                            $html_output .= '<span class="cb-success">OK ' . __('E-Mail versendet', self::TEXT_DOMAIN) . '</span>';
                            $success_count++;

                            sleep(2);

                        } catch (\Exception $mail_exception) {
                            $error_message = $mail_exception->getMessage();

                            if (
                                strpos($error_message, 'mail send limit exceeded') !== false ||
                                strpos($error_message, 'mailbox unavailable') !== false ||
                                strpos($error_message, '450') !== false
                            ) {
                                $html_output .= '<span class="cb-error">PAUSE ' . __('E-Mail-Limit erreicht - pausiere 30 Sekunden', self::TEXT_DOMAIN) . '</span>';
                                sleep(30);

                                try {
                                    $booking_message = new \CommonsBooking\Messages\BookingMessage($booking_id, 'confirmed');
                                    $booking_message->triggerMail();
                                    $html_output .= '<br><span class="cb-success">OK ' . __('E-Mail nach Pause erfolgreich versendet', self::TEXT_DOMAIN) . '</span>';
                                    $success_count++;
                                } catch (\Exception $retry_exception) {
                                    $html_output .= '<br><span class="cb-error">FEHLER ' . __('E-Mail auch nach Pause fehlgeschlagen: ', self::TEXT_DOMAIN) . esc_html($retry_exception->getMessage()) . '</span>';
                                    $errors[] = sprintf(__('Buchung #%d: %s', self::TEXT_DOMAIN), $booking_id, $retry_exception->getMessage());
                                    $error_count++;
                                }
                            } else {
                                $html_output .= '<span class="cb-error">FEHLER ' . __('E-Mail-Fehler: ', self::TEXT_DOMAIN) . esc_html($error_message) . '</span>';
                                $errors[] = sprintf(__('Buchung #%d: %s', self::TEXT_DOMAIN), $booking_id, $error_message);
                                $error_count++;
                            }

                            sleep(1);
                        }
                    } else {
                        $html_output .= '<span class="cb-warning">PREVIEW ' . __('Vorschau (E-Mail nicht versendet)', self::TEXT_DOMAIN) . '</span>';
                    }

                    $html_output .= '</li>';

                } catch (\Exception $e) {
                    $error_message = sprintf(__('Buchung #%d: %s', self::TEXT_DOMAIN), $booking_id, $e->getMessage());
                    $errors[] = $error_message;
                    $error_count++;

                    $html_output .= '<span class="cb-error">FEHLER ' . __('Fehler: ', self::TEXT_DOMAIN) . esc_html($e->getMessage()) . '</span>';
                    $html_output .= '</li>';
                }
            }

            $html_output .= '</ul></div>';

            $html_output .= '<div class="cb-final-summary">';
            $html_output .= '<h4>' . __('Zusammenfassung:', self::TEXT_DOMAIN) . '</h4>';

            if (!$is_preview) {
                $html_output .= '<p><strong>' . sprintf(__('Erfolgreich versendet: %d E-Mails', self::TEXT_DOMAIN), $success_count) . '</strong></p>';
                $html_output .= '<p><strong>' . sprintf(__('Fehler: %d', self::TEXT_DOMAIN), $error_count) . '</strong></p>';
            } else {
                $html_output .= '<p><strong>' . sprintf(__('Buchungen in Vorschau: %d', self::TEXT_DOMAIN), count($bookings)) . '</strong></p>';
            }

            if (!empty($errors)) {
                $html_output .= '<h5>' . __('Fehlerdetails:', self::TEXT_DOMAIN) . '</h5><ul>';
                foreach ($errors as $error) {
                    $html_output .= '<li class="cb-error">' . esc_html($error) . '</li>';
                }
                $html_output .= '</ul>';
            }

            $html_output .= '<p class="cb-success"><strong>' . sprintf(__('Verarbeitung abgeschlossen um: %s', self::TEXT_DOMAIN), date('d.m.Y H:i:s')) . '</strong></p>';
            $html_output .= '</div>';

            wp_send_json_success(['html' => $html_output]);

        } catch (\RuntimeException $e) {
            if ($e->getMessage() === 'cbaf_json_sent') {
                throw $e;
            }
            wp_send_json_error(__('Kritischer Fehler: ', self::TEXT_DOMAIN) . $e->getMessage());
        } catch (\Exception $e) {
            wp_send_json_error(__('Kritischer Fehler: ', self::TEXT_DOMAIN) . $e->getMessage());
        }
    }

    public function add_resend_email_action($actions, $post)
    {
        if ($post->post_type !== 'cb_booking') {
            return $actions;
        }

        if (get_post_meta($post->ID, 'type', true) !== '6') {
            return $actions;
        }

        if (!current_user_can('manage_options')) {
            return $actions;
        }

        $actions['cbadf_resend_email'] = sprintf(
            '<a href="#" class="cb-resend-email-link" data-booking-id="%d" title="%s">%s</a>',
            $post->ID,
            esc_attr__('Bestaetigungs-E-Mail fuer diese Buchung erneut versenden', self::TEXT_DOMAIN),
            __('Email erneut versenden', self::TEXT_DOMAIN)
        );

        return $actions;
    }

    public function handle_single_email_resend()
    {
        if (!check_ajax_referer('cbadf_resend_single_email', 'nonce', false)) {
            wp_send_json_error(__('Sicherheitspruefung fehlgeschlagen.', self::TEXT_DOMAIN));
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Keine Berechtigung.', self::TEXT_DOMAIN));
        }

        if (!class_exists('CommonsBooking\Repository\Booking')) {
            wp_send_json_error(__('CommonBooking Plugin ist nicht aktiv.', self::TEXT_DOMAIN));
        }

        $booking_id = isset($_POST['booking_id']) ? intval($_POST['booking_id']) : 0;

        try {
            $booking = \CommonsBooking\Repository\Booking::getPostById($booking_id);

            if (!$booking || get_post_meta($booking_id, 'type', true) !== '6') {
                wp_send_json_error(__('Buchung wurde nicht gefunden oder ist keine bestaetigte Buchung.', self::TEXT_DOMAIN));
            }

            $booking_message = new \CommonsBooking\Messages\BookingMessage($booking_id, 'confirmed');
            $booking_message->triggerMail();

            $user_data = $booking->getUserData();
            $success_message = sprintf(
                __('E-Mail erfolgreich versendet an %s fuer Buchung #%d', self::TEXT_DOMAIN),
                $user_data->user_email,
                $booking_id
            );

            wp_send_json_success($success_message);

        } catch (\RuntimeException $e) {
            if ($e->getMessage() === 'cbaf_json_sent') {
                throw $e;
            }
            wp_send_json_error(__('Fehler beim Versenden: ', self::TEXT_DOMAIN) . $e->getMessage());
        } catch (\Exception $e) {
            wp_send_json_error(__('Fehler beim Versenden: ', self::TEXT_DOMAIN) . $e->getMessage());
        }
    }

    public function add_inline_resend_script()
    {
        global $current_screen;

        if (!$current_screen || $current_screen->id !== 'edit-cb_booking') {
            return;
        }
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(document).on('click', '.cb-resend-email-link', function(e) {
                e.preventDefault();

                var $link = $(this);
                var bookingId = $link.data('booking-id');
                var originalText = $link.text();

                if (!confirm('<?php _e('Moechten Sie die Bestaetigungs-E-Mail fuer diese Buchung wirklich erneut versenden?', self::TEXT_DOMAIN); ?>')) {
                    return;
                }

                $link.text('<?php _e('Wird versendet...', self::TEXT_DOMAIN); ?>').addClass('cb-sending');

                $.post(ajaxurl, {
                    action: 'cbadf_resend_single_email',
                    booking_id: bookingId,
                    nonce: '<?php echo wp_create_nonce('cbadf_resend_single_email'); ?>'
                })
                .done(function(response) {
                    if (response.success) {
                        $('h1.wp-heading-inline').after(
                            '<div class="notice notice-success is-dismissible"><p>' +
                            response.data +
                            '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php _e('Diese Benachrichtigung ausblenden', self::TEXT_DOMAIN); ?></span></button></div>'
                        );

                        $link.text('<?php _e('Versendet', self::TEXT_DOMAIN); ?>').removeClass('cb-sending').addClass('cb-sent');

                        setTimeout(function() {
                            $link.text(originalText).removeClass('cb-sent');
                        }, 3000);

                    } else {
                        $('h1.wp-heading-inline').after(
                            '<div class="notice notice-error is-dismissible"><p><strong><?php _e('Fehler:', self::TEXT_DOMAIN); ?></strong> ' +
                            response.data +
                            '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php _e('Diese Benachrichtigung ausblenden', self::TEXT_DOMAIN); ?></span></button></div>'
                        );

                        $link.text(originalText).removeClass('cb-sending');
                    }
                })
                .fail(function(xhr, status, error) {
                    $('h1.wp-heading-inline').after(
                        '<div class="notice notice-error is-dismissible"><p><strong><?php _e('AJAX-Fehler:', self::TEXT_DOMAIN); ?></strong> ' +
                        error +
                        '</p><button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php _e('Diese Benachrichtigung ausblenden', self::TEXT_DOMAIN); ?></span></button></div>'
                    );

                    $link.text(originalText).removeClass('cb-sending');
                });

                $(document).on('click', '.notice-dismiss', function() {
                    $(this).closest('.notice').fadeOut();
                });
            });
        });
        </script>

        <style>
        .cb-resend-email-link.cb-sending {
            color: #ffb900 !important;
            pointer-events: none;
        }
        .cb-resend-email-link.cb-sent {
            color: #46b450 !important;
        }
        </style>
        <?php
    }

    public function commonsbooking_missing_notice()
    {
        if (!function_exists('get_current_screen')) {
            return;
        }

        $screen = get_current_screen();
        if (!$screen) {
            return;
        }

        if (!in_array($screen->id, ['cbadf_page_' . self::PLUGIN_SLUG, 'edit-cb_booking'], true)) {
            return;
        }
        ?>
        <div class="notice notice-warning">
            <p>
                <strong><?php _e('CommonBooking E-Mail Resender:', self::TEXT_DOMAIN); ?></strong>
                <?php _e('Das CommonBooking Plugin muss installiert und aktiviert sein fuer die volle Funktionalitaet.', self::TEXT_DOMAIN); ?>
            </p>
        </div>
        <?php
    }
}
