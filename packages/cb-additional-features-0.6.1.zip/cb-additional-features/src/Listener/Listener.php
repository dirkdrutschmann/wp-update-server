<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\Listener;

use CommonsBooking\Model\Booking as ModelBooking;
use CommonsBooking\Model\Item as ItemModel;
use CommonsBooking\Model\Location as LocationModel;
use CommonsBooking\Repository\Booking as Bookings;
use CommonsBooking\Wordpress\CustomPostType\Booking as BookingPostType;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\BlacklistLog;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\BlacklistSettings;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\Log;

class Listener
{
    private bool $hasValidatedRequest = false;

    public function __construct()
    {
        add_action('init', [$this, 'handleFrontendBooking'], 40);
    }

    public function handleFrontendBooking(): void
    {
        if ($this->hasValidatedRequest || !is_user_logged_in()) {
            return;
        }

        if (!$this->isBookingRequest()) {
            return;
        }

        $this->hasValidatedRequest = true;

        $request = $this->parseRequest();

        if (!$request) {
            return;
        }

        $context = $this->evaluateRules($request);

        if (!$context) {
            return;
        }

        $this->logBlockedAttempt($request, $context);

        $message = $this->buildNoticeMessage($request, $context);

        set_transient(
            BookingPostType::ERROR_TYPE . '-' . $request['user_id'],
            $message,
            30
        );

        $redirectUrl = add_query_arg('cb-location', $request['location_id'], get_permalink($request['item_id']));
        wp_safe_redirect($redirectUrl);
        exit;
    }

    private function isBookingRequest(): bool
    {
        if (!function_exists('wp_verify_nonce')) {
            return false;
        }

        $nonceId = BookingPostType::getWPNonceId();
        $action = BookingPostType::getWPAction();

        if (
            empty($_REQUEST[$nonceId]) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST[$nonceId])), $action)
        ) {
            return false;
        }

        return isset($_REQUEST['booking-update']);
    }

    private function parseRequest(): ?array
    {
        $itemId = isset($_REQUEST['item-id']) ? intval($_REQUEST['item-id']) : 0;
        $locationId = isset($_REQUEST['location-id']) ? intval($_REQUEST['location-id']) : 0;
        $start = isset($_REQUEST[\CommonsBooking\Model\Timeframe::REPETITION_START])
            ? intval($_REQUEST[\CommonsBooking\Model\Timeframe::REPETITION_START])
            : 0;
        $end = isset($_REQUEST[\CommonsBooking\Model\Timeframe::REPETITION_END])
            ? intval($_REQUEST[\CommonsBooking\Model\Timeframe::REPETITION_END])
            : 0;

        if (!$itemId || !$locationId || !$start || !$end) {
            return null;
        }

        return [
            'item_id' => $itemId,
            'location_id' => $locationId,
            'start' => $start,
            'end' => $end,
            'user_id' => get_current_user_id(),
        ];
    }

    private function evaluateRules(array $request): ?array
    {
        $options = BlacklistSettings::getOptions();
        $bookings = $this->getConfirmedBookings();

        foreach (['item', 'location', 'global'] as $rule) {
            $context = $this->checkRule($rule, $request, $options, $bookings);
            if ($context) {
                return $context;
            }
        }

        return null;
    }

    private function checkRule(string $rule, array $request, array $options, array $bookings): ?array
    {
        $config = $this->getRuleConfig($rule, $options, $request);

        if (!$config['active'] || $config['limit'] <= 0 || $config['interval'] <= 0) {
            return null;
        }

        if ($this->shouldSkipForAdmins($rule, $request, $config)) {
            return null;
        }

        $intervals = $this->buildIntervals($bookings, $config['filter'], $request);

        if (!$intervals) {
            return null;
        }

        $violates = $this->violatesThreshold(
            $intervals,
            $request['end'],
            $config['interval'] * DAY_IN_SECONDS,
            $config['limit']
        );

        if (!$violates) {
            return null;
        }

        return [
            'rule' => $rule,
            'limit' => $config['limit'],
            'interval' => $config['interval'],
            'item_id' => $request['item_id'],
            'location_id' => $request['location_id'],
        ];
    }

    private function getRuleConfig(string $rule, array $options, array $request): array
    {
        $config = [
            'active' => false,
            'limit' => 0,
            'interval' => 0,
            'include_admins' => false,
            'filter' => static function ($booking) {
                return false;
            },
        ];

        switch ($rule) {
            case 'item':
                $config['active'] = !empty($options['blacklist_item_active']);
                $config['limit'] = isset($options['blacklist_item']) ? intval($options['blacklist_item']) : 0;
                $config['interval'] = isset($options['blacklist_item_interval']) ? intval($options['blacklist_item_interval']) : 0;
                $config['include_admins'] = !empty($options['blacklist_item_include_admins']);
                $itemId = $request['item_id'] ?? 0;
                $config['filter'] = static function (ModelBooking $booking) use ($itemId) {
                    try {
                        return $booking->getItem() && $booking->getItem()->ID === $itemId;
                    } catch (\Exception $e) {
                        return false;
                    }
                };
                break;
            case 'location':
                $config['active'] = !empty($options['blacklist_location_active']);
                $config['limit'] = isset($options['blacklist_location']) ? intval($options['blacklist_location']) : 0;
                $config['interval'] = isset($options['blacklist_location_interval']) ? intval($options['blacklist_location_interval']) : 0;
                $config['include_admins'] = !empty($options['blacklist_location_include_admins']);
                $locationId = $request['location_id'] ?? 0;
                $config['filter'] = static function (ModelBooking $booking) use ($locationId) {
                    try {
                        return $booking->getLocation() && $booking->getLocation()->ID === $locationId;
                    } catch (\Exception $e) {
                        return false;
                    }
                };
                break;
            case 'global':
                $config['active'] = !empty($options['blacklist_global_active']);
                $config['limit'] = isset($options['blacklist_global']) ? intval($options['blacklist_global']) : 0;
                $config['interval'] = isset($options['blacklist_global_interval']) ? intval($options['blacklist_global_interval']) : 0;
                $config['include_admins'] = !empty($options['blacklist_global_include_admins']);
                $userId = $request['user_id'] ?? 0;
                $config['filter'] = function (ModelBooking $booking) use ($userId) {
                    try {
                        // Buchungen herausfiltern, wenn Nutzer Admin für Item oder Location ist
                        $item = $booking->getItem();
                        $location = $booking->getLocation();
                        
                        if ($item && $this->isItemAdmin($userId, $item->ID)) {
                            return false; // Nicht zählen, wenn Item-Admin
                        }
                        
                        if ($location && $this->isLocationAdmin($userId, $location->ID)) {
                            return false; // Nicht zählen, wenn Location-Admin
                        }
                        
                        return true; // Zählen, wenn nicht Admin
                    } catch (\Exception $e) {
                        return true; // Bei Fehler zählen (sicherer Fall)
                    }
                };
                break;
        }

        return $config;
    }

    private function shouldSkipForAdmins(string $rule, array $request, array $config): bool
    {
        if ($config['include_admins']) {
            return false;
        }

        switch ($rule) {
            case 'item':
                return $this->isItemAdmin($request['user_id'], $request['item_id']);
            case 'location':
                return $this->isLocationAdmin($request['user_id'], $request['location_id']);
            case 'global':
                return $this->isGlobalAdmin();
            default:
                return false;
        }
    }

    private function getConfirmedBookings(): array
    {
        $bookings = Bookings::getForCurrentUser(true);

        if (!is_array($bookings)) {
            return [];
        }

        return array_values(
            array_filter($bookings, function ($booking) {
                return $booking instanceof ModelBooking && $booking->post_status === 'confirmed';
            })
        );
    }

    private function buildIntervals(array $bookings, callable $filter, array $request): array
    {
        $intervals = [];

        foreach ($bookings as $booking) {
            if ($filter($booking)) {
                $intervals[] = [
                    'start' => $booking->getStartDate(),
                    'end' => $booking->getEndDate(),
                ];
            }
        }

        if (!empty($request['start']) && !empty($request['end'])) {
            $intervals[] = [
                'start' => $request['start'],
                'end' => $request['end'],
            ];
        }

        return $intervals;
    }

    private function violatesThreshold(array $intervals, int $baseEnd, int $intervalSeconds, int $limit): bool
    {
        if ($intervalSeconds <= 0 || $limit <= 0 || !$baseEnd) {
            return false;
        }

        $intervals = array_values(
            array_filter($intervals, function ($interval) use ($baseEnd, $intervalSeconds) {
                if (empty($interval['end'])) {
                    return false;
                }
                return abs($interval['end'] - $baseEnd) < $intervalSeconds;
            })
        );

        if (!$intervals) {
            return false;
        }

        usort($intervals, function ($a, $b) {
            return ($a['start'] ?? 0) <=> ($b['start'] ?? 0);
        });

        $count = 0;
        foreach ($intervals as $index => $interval) {
            if ($index > 0) {
                $gap = ($intervals[$index]['start'] ?? 0) - ($intervals[$index - 1]['end'] ?? 0);
                if ($gap > $intervalSeconds) {
                    $count = 0;
                }
            }
            $count++;
            if ($count >= $limit) {
                return true;
            }
        }

        return false;
    }

    private function isItemAdmin(int $userId, int $itemId): bool
    {
        try {
            $post = get_post($itemId);
            if (!$post) {
                return false;
            }
            $item = new ItemModel($post);
            return in_array($userId, $item->getAdmins(), true);
        } catch (\Exception $e) {
            return false;
        }
    }

    private function isLocationAdmin(int $userId, int $locationId): bool
    {
        try {
            $post = get_post($locationId);
            if (!$post) {
                return false;
            }
            $location = new LocationModel($post);
            return in_array($userId, $location->getAdmins(), true);
        } catch (\Exception $e) {
            return false;
        }
    }

    private function isGlobalAdmin(): bool
    {
        if (function_exists('commonsbooking_isCurrentUserAdmin')) {
            return commonsbooking_isCurrentUserAdmin();
        }

        return current_user_can('manage_options');
    }

    private function logBlockedAttempt(array $request, array $context): void
    {
        $message = sprintf(
            '[Blacklist] User %d blocked for %s rule (item %d, location %d, start %s, end %s, limit %d/%d days)',
            $request['user_id'],
            $context['rule'],
            $request['item_id'],
            $request['location_id'],
            date_i18n('Y-m-d H:i', $request['start']),
            date_i18n('Y-m-d H:i', $request['end']),
            $context['limit'],
            $context['interval']
        );

        Log::log($message);

        BlacklistLog::addEntry([
            'user_id' => $request['user_id'],
            'item_id' => $request['item_id'],
            'location_id' => $request['location_id'],
            'rule' => $context['rule'],
            'start' => $request['start'],
            'end' => $request['end'],
        ]);
    }

    private function buildNoticeMessage(array $request, array $context): string
    {
        $reasonLabels = [
            'item' => __('Artikel', 'cb-additional-features'),
            'location' => __('Standort', 'cb-additional-features'),
            'global' => __('Buchung', 'cb-additional-features'),
        ];

        $template = BlacklistSettings::getNoticeText();
        $template = strtr($template, [
            '{{reason}}' => $reasonLabels[$context['rule']] ?? $context['rule'],
            '{{limit}}' => $context['limit'],
            '{{interval}}' => $context['interval'],
        ]);

        if (function_exists('commonsbooking_parse_template')) {
            $templateObjects = [
                'item' => $this->getItemModel($request['item_id']),
                'location' => $this->getLocationModel($request['location_id']),
                'user' => wp_get_current_user(),
            ];
            $template = commonsbooking_parse_template($template, $templateObjects);
        }

        return $template;
    }

    private function getItemModel(int $itemId): ?ItemModel
    {
        try {
            $post = get_post($itemId);
            return $post ? new ItemModel($post) : null;
        } catch (\Exception $e) {
            return null;
        }
    }

    private function getLocationModel(int $locationId): ?LocationModel
    {
        try {
            $post = get_post($locationId);
            return $post ? new LocationModel($post) : null;
        } catch (\Exception $e) {
            return null;
        }
    }
}
