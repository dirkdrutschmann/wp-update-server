<?php
/*
Plugin Name: Commons Booking Additional Feature
Description: Dieses Plugin erweitert Common Bookings um die Funktion der Einpflege von Urlaubstagen. Fügt eine andere Buchungshistorie und eine Sidebar hinzu.
Author: Dirk Drutschmann
Version: 0.6.3
*/

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Plugin\Plugin;
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

defined('ABSPATH') or die("Thanks for visting");

require 'vendor/autoload.php';

$loader = new Plugin();

$myUpdateChecker = PucFactory::buildUpdateChecker(
    'https://updates.drutschmann.dev/?action=get_metadata&slug=cb-additional-features',
    __FILE__, //Full path to the main plugin file or functions.php.
    'cb-additional-features'
);
