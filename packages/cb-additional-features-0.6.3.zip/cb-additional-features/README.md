# Commons Booking Additional Features

Dieses WordPress-Plugin erweitert das **CommonsBooking**-Plugin um zusätzliche Funktionen für Verwaltung, Kommunikation und Darstellung.

## Voraussetzungen

- WordPress
- Aktives Plugin **CommonsBooking**
- PHP 8.0+

## Funktionen

- Backend-Menü **„CB Additional Features“** mit Unterseiten:
  - **Sidebar**: Zuordnung von Seiten/Links (z. B. „Meine Buchungen“, „Profil“, „Konto“) und Werbetext.
  - **Feiertage**: Einpflegen und Entfernen von Feiertagen (Timeframes) für CommonsBooking.
  - **Blacklist**: Regeln zur Begrenzung von Buchungen pro Nutzer (Item, Standort, global) inkl. automatischer Ablehnung und Benachrichtigung.
  - **QR-Code**: QR-Code in Buchungsbestätigungs-E-Mails und Check-Seite zur Buchungsprüfung.
  - **Statistik**: Auswertungen und Export als Excel-Datei.
- **E-Mail Resender**: Admin-Seite zum erneuten Versenden von Buchungsbestätigungen.
- **Kurzcodes**
  - `[cbaf_bookings]`: Aktuelle Buchungen des eingeloggten Nutzers.
  - `[cbaf_sidebar]`: Sidebar mit Links/Profil/Logout und Werbeinhalten.
  - `[cb_qr_check]`: Check-Seite für QR-Code-Buchungsprüfung (wird bei Bedarf automatisch angelegt).
- **Backend-Filter für Buchungen**: Filter nach Benutzername oder E‑Mail-Adresse in der Buchungsliste.

## Installation

1. Plugin in `wp-content/plugins/` ablegen.
2. Abhängigkeiten installieren (falls nötig):
   ```bash
   composer install
   ```
3. Plugin in WordPress aktivieren.

## Hinweise

- Einige Funktionen sind nur verfügbar, wenn **CommonsBooking** aktiv ist.
- Die QR-Code-Funktion kann in den Plugin-Einstellungen aktiviert/deaktiviert werden.
