# Deploy-Anweisungen

Dieses Projekt deployt **nur bei Tag-Pushes**. Ein normaler Push auf `master` führt **nur Tests** aus.

## Voraussetzungen

- Schreibrechte auf das Repository
- Zugriff auf das Update-Server-Repository via `UPDATE_SERVER_TOKEN` (GitHub Actions Secret)

## Release/Deploy durchführen

1. Version im Plugin erhöhen
   - Datei: `cb-additional-features.php`
   - Beispiel: `Version: 0.6.3`

2. Commit erstellen
   ```bash
   git add cb-additional-features.php
   git commit -m "Version 0.6.3"
   git push
   ```

3. Tag setzen und pushen (startet Deploy)
   ```bash
   git tag v0.6.3
   git push origin v0.6.3
   ```

## Was passiert beim Deploy

- CI baut ein Zip‑Paket des Plugins.
- Das Paket wird in das Update‑Server‑Repository kopiert.
- Es werden zwei Dateien veröffentlicht:
  - `cb-additional-features.zip`
  - `cb-additional-features-<VERSION>.zip`

## Hinweise

- Der Deploy wird **nur** ausgelöst, wenn ein Tag mit Präfix `v` gepusht wird (z. B. `v0.6.3`).
- `workflow_dispatch` führt nur Tests aus und publiziert nichts.
