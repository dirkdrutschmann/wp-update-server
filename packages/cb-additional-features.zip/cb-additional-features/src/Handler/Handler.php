<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\Handler;

use CommonsBooking\Model\Booking;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\Log;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\Holiday;
use CommonsBooking\Wordpress\CustomPostType\Timeframe;
use CommonsBooking\Repository\Timeframe as RepositoryTimeframe;

class Handler
{


    public function __construct()
    {
        add_action('admin_post_add_holiday', [$this, 'holiday']);
    }

    public function holiday()
    {
        if (
            !isset($_POST['holiday_nonce']) ||
            !wp_verify_nonce($_POST['holiday_nonce'], 'add_holiday')
        ) {
            $_SESSION['error'] = "Leider ist ein Fehler aufgetreten, bitte Formular erneut senden!";
            exit();
        } else {
                $timeframes = [];
            if(isset($_POST['timeframes'])){
                $timeframes = [];
            }
            if ($_POST['add_holiday']) {
                $result = ["success" => 0, "exists" => 0];
                $holidays = RepositoryTimeframe::get($timeframes, [], [Timeframe::BOOKABLE_ID]);

                foreach ($holidays as $holiday) {
                    $results = Holiday::addHolidays(new \CommonsBooking\Model\Timeframe($holiday));
                    $result["success"] += $results['success'];
                    $result["exists"] += $results['exists'];
                }

                $retunString  = "";
                if ($result["success"] > 0) {
                    $retunString .= $result["success"] . " Feiertage wurden erfolgreich eingetragen. ";
                }
                if ($result["exists"] > 0) {
                    $retunString .= $result["exists"] . " Feiertage bereits vorhanden. ";
                }
                $_SESSION['success'] = $retunString;
                wp_redirect(admin_url('admin.php?page=cbadf-timeframe'));
            } else if ($_POST['remove_holiday']) {
                $result = ["success" => 0];
                $holidays = RepositoryTimeframe::get($timeframes, [], [Timeframe::HOLIDAYS_ID]);

                foreach ($holidays as $holiday) {
                    wp_delete_post($holiday->ID, true);
                    $result['success']++;
                }

                $retunString  = "";
                $retunString .= $result["success"] . " Feiertage wurden gelöscht.";
                $_SESSION['error'] = $retunString;
                wp_redirect(admin_url('admin.php?page=cbadf-timeframe'));
            } else {
                $_SESSION['error'] = "Leider ist ein Fehler aufgetreten, bitte Formular erneut senden!";
                exit();
            }
        }
    }
}
