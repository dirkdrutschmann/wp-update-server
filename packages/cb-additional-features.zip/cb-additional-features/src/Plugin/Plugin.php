<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\Plugin;

use DirkDrutschmann\CommonbookingsAdditionalFeatures\Cron\CronJob;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Admin\BookingUserFilter;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Handler\Handler;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Listener\Listener;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\QrCode\QrCodeSender;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Resender\EmailResender;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Setting\SettingPage;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Shortcodes\Shortcode;
use PhpOffice\PhpSpreadsheet\Exception;

defined('ABSPATH') or die("Thanks for visting");

class Plugin
{

    public function __construct()
    {
        add_filter('https_ssl_verify', '__return_false');
        add_action('wp_enqueue_scripts', [$this, 'scripts']);
        add_action('admin_enqueue_scripts', [$this, 'admin_scripts']);
        add_action( 'plugins_loaded', [$this,'my_plugin_init'] );     
        $shortcode = new Shortcode();
        $listener = new Listener();
        $cronjob = new CronJob();
        $qrCodeSender = new QrCodeSender();
        // Check if the class exists
        if (is_admin()) {
            $settingpage = new SettingPage();
            $handler = new Handler();
            $emailResender = new EmailResender();
            $bookingUserFilter = new BookingUserFilter();
        }
    }


    function my_plugin_init() {
        if( !class_exists('CommonsBooking\Plugin') ) {
            add_action('admin_notices', [$this, 'custom_admin_notice']);
        }
    }

    function custom_admin_notice()
    {
        echo '<div class="notice notice-error is-dismissible">
          <p>Das Plugin "Common Bookings" von wielebenwir e.V. wurde nicht gefunden! Additonal Features sind nur mit installiertem und aktiviertem Plugin möglich! <a href="https://wordpress.org/plugins/commonsbooking/"> Zum Plugin </a></p> </div>';
    }

    public function scripts()
    {
        wp_enqueue_script('jquery');
        wp_register_style(
            'my-stylesheet',
            plugin_dir_url(dirname(__DIR__)) . '/assets/css/styles.css'
        );

        wp_enqueue_style('my-stylesheet');

        wp_register_style(
            'bootstrap-style',
            plugin_dir_url(dirname(__DIR__)) . '/assets/css/bootstrap.min.css',
            [],
            '5.1.3'
        );
      
    }

    public function admin_scripts()
    {
        wp_enqueue_script('jquery');
        wp_register_style(
            'select-stylesheet',
            plugin_dir_url(dirname(__DIR__)) . '/assets/css/select2.min.css'
        );
        wp_enqueue_style('select-stylesheet');
        wp_register_style(
            'admin-stylesheet',
            plugin_dir_url(dirname(__DIR__)) . '/assets/css/admin-styles.css'
        );
        wp_enqueue_style('admin-stylesheet');
        wp_enqueue_script(
            'select-js',
            plugin_dir_url(dirname(__DIR__)) .
                '/assets/js/select2.full.min.js',
            ['jquery'],
            '',
            false
        );
  
        wp_register_style(
            'bootstrap-style',
            plugin_dir_url(dirname(__DIR__)) . '/assets/css/bootstrap.min.css',
            [],
            '5.1.3'
        );
        wp_enqueue_style('bootstrap-style');

    }
}
