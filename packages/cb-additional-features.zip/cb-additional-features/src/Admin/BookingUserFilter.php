<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\Admin;

class BookingUserFilter
{
    private const FILTER_PARAM = 'admin_filter_user';
    private const TEXT_DOMAIN = 'cb-additional-features';

    public function __construct()
    {
        add_action('restrict_manage_posts', [$this, 'renderFilter']);
        add_action('pre_get_posts', [$this, 'applyFilter']);
    }

    public function renderFilter(): void
    {
        if (!$this->isBookingListScreen()) {
            return;
        }

        $value = $this->getRequestValue(self::FILTER_PARAM);
        $placeholder = __('User / E-Mail', self::TEXT_DOMAIN);

        printf(
            '<input type="text" name="%s" id="%s" value="%s" placeholder="%s" class="cbadf-user-filter" />',
            esc_attr(self::FILTER_PARAM),
            esc_attr(self::FILTER_PARAM),
            esc_attr($value),
            esc_attr($placeholder)
        );
    }

    public function applyFilter(\WP_Query $query): void
    {
        if (!$this->isBookingListQuery($query)) {
            return;
        }

        $filterValue = $this->getRequestValue(self::FILTER_PARAM);
        $searchValue = $this->getRequestValue('s');
        $term = $filterValue !== '' ? $filterValue : $searchValue;

        if ($term === '') {
            return;
        }

        $userIds = $this->findUserIds($term);

        if (empty($userIds)) {
            if ($filterValue !== '') {
                $query->set('author__in', [0]);
                $query->set('s', '');
            }
            return;
        }

        $query->set('author__in', $userIds);
        $query->set('s', '');
    }

    private function isBookingListScreen(): bool
    {
        if (!is_admin() || !function_exists('get_current_screen')) {
            return false;
        }

        $screen = get_current_screen();
        if (!$screen) {
            return false;
        }

        return $screen->id === 'edit-' . $this->getBookingPostType();
    }

    private function isBookingListQuery(\WP_Query $query): bool
    {
        if (!is_admin() || !$query->is_main_query()) {
            return false;
        }

        global $pagenow;
        if ($pagenow !== 'edit.php') {
            return false;
        }

        $postType = $query->get('post_type');
        if (is_array($postType)) {
            $postType = reset($postType);
        }

        if (!$postType && isset($_GET['post_type'])) {
            $postType = sanitize_text_field(wp_unslash($_GET['post_type']));
        }

        return $postType === $this->getBookingPostType();
    }

    private function getRequestValue(string $key): string
    {
        if (!isset($_GET[$key])) {
            return '';
        }

        return trim(sanitize_text_field(wp_unslash($_GET[$key])));
    }

    private function findUserIds(string $term): array
    {
        $term = trim($term);
        if ($term === '') {
            return [];
        }

        $ids = [];

        if (ctype_digit($term)) {
            $user = get_user_by('ID', (int) $term);
            if ($user) {
                $ids[] = (int) $user->ID;
            }
        }

        $ids = array_merge($ids, $this->findUsersByCoreFields($term));
        $ids = array_merge($ids, $this->findUsersByMeta($term));

        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));

        return $ids;
    }

    private function findUsersByCoreFields(string $term): array
    {
        return get_users([
            'fields' => 'ID',
            'search' => '*' . $term . '*',
            'search_columns' => ['user_login', 'user_email', 'display_name'],
        ]);
    }

    private function findUsersByMeta(string $term): array
    {
        $query = new \WP_User_Query([
            'fields' => 'ID',
            'meta_query' => [
                'relation' => 'OR',
                [
                    'key' => 'first_name',
                    'value' => $term,
                    'compare' => 'LIKE',
                ],
                [
                    'key' => 'last_name',
                    'value' => $term,
                    'compare' => 'LIKE',
                ],
            ],
        ]);

        return $query->get_results();
    }

    private function getBookingPostType(): string
    {
        if (class_exists('\\CommonsBooking\\Wordpress\\CustomPostType\\Booking')) {
            return \CommonsBooking\Wordpress\CustomPostType\Booking::$postType;
        }

        return 'cb_booking';
    }
}
