<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\Setting;

use CommonsBooking\Repository\Booking;
use CommonsBooking\Repository\Location;
use DateTime;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\BlacklistLog;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\BlacklistSettings;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\ConfirmedPosts;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\Date;
use CommonsBooking\Model\Booking as ModelBooking;
use CommonsBooking\Wordpress\CustomPostType\Booking as CustomPostTypeBooking;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\TemplateLoader;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\UserStatistik;
use PhpOffice\PhpSpreadsheet\Exception;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Fill;


class SettingPage
{
    private $commonbookings_additional_features_options;
    private $commonbookings_additional_features_blacklist;
    private $commonbookings_additional_features_qrcode;
    protected $cachedResults;
    private $cache = [];

    public function __construct()
    {
        add_action('admin_menu', [
            $this,
            'commonbookings_additional_features_add_pages',
        ]);
        add_action('admin_init', [
            $this,
            'commonbookings_additional_features_page_init',
        ]);
        add_action('admin_init', [
            $this,
            'commonbookings_additional_features_blacklist_init',
        ]);
        add_action('admin_init', [
            $this,
            'commonbookings_additional_features_qrcode_init',
        ]);
        add_action('admin_init', [
            $this,
            'commonbookings_additional_features_generate_excel',
        ]);



    }

    public function commonbookings_additional_features_add_pages()
    {
        add_menu_page(
            'CB Additional Features', // page_title
            'CB Additional Features', // menu_title
            'manage_options', // capability
            'cbadf', // menu_slug
            '', // function
            plugin_dir_url(dirname(__DIR__)) . '/assets/images/icon.png' // icon_url
        // position
        );

        add_submenu_page(
            'cbadf', //parent slug
            'Sidebar', // page_title
            'Sidebar', // menu_title
            'manage_options', // capability
            'cbadf', //menu_slug
            [$this, 'commonbookings_additional_features_create_page'] // function
        );
        add_submenu_page(
            'cbadf', //parent slug
            'Feiertage', // page_title
            'Feiertage', // menu_title
            'manage_options', // capability
            'cbadf-timeframe', //menu_slug
            [$this, 'common_bookings_additional_features_create_timeframe_page'] // function
        );
        add_submenu_page(
            'cbadf', //parent slug
            'Blacklist', // page_title
            'Blacklist', // menu_title
            'manage_options', // capability
            'cbadf-blacklist', //menu_slug
            [$this, 'common_bookings_additional_features_create_blacklist_page'] // function
        );
        add_submenu_page(
            'cbadf', //parent slug
            'QR-Code', // page_title
            'QR-Code', // menu_title
            'manage_options', // capability
            'cbadf-qrcode', //menu_slug
            [$this, 'common_bookings_additional_features_create_qrcode_page'] // function
        );
        add_submenu_page(
            'cbadf', //parent slug
            'Statistik', // page_title
            'Statistik', // menu_title
            'manage_options', // capability
            'cbadf-statistik', //menu_slug
            [$this, 'common_bookings_additional_features_create_statistik_page'] // function
        );
    }

    public function commonbookings_additional_features_create_page()
    {
        $this->commonbookings_additional_features_options = get_option(
            'commonbookings_additional_features_option_name'
        ); ?>

        <div class="wrap">
            <h2>CommonBookings Additional Features</h2>
            <hr>
            <p></p>
            <?php settings_errors(); ?>

            <form method="post" action="options.php">
                <?php
                settings_fields('commonbookings_additional_features_option_group');
                do_settings_sections('commonbookings-additional-features-admin');
                submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function commonbookings_additional_features_page_init()
    {
        register_setting(
            'commonbookings_additional_features_option_group', // option_group
            'commonbookings_additional_features_option_name', // option_name
            [$this, 'commonbookings_additional_features_sanitize'] // sanitize_callback
        );

        add_settings_section(
            'commonbookings_additional_features_setting_section', // id
            'Sidebar', // title
            [$this, 'commonbookings_additional_features_section_info'], // callback
            'commonbookings-additional-features-admin' // page
        );

        add_settings_field(
            'werbung_0', // id
            'Werbung', // title
            [$this, 'werbung_0_callback'], // callback
            'commonbookings-additional-features-admin', // page
            'commonbookings_additional_features_setting_section' // section
        );

        add_settings_field(
            'buchung_0', // id
            'meine Buchungen', // title
            [$this, 'buchung_0_callback'], // callback
            'commonbookings-additional-features-admin', // page
            'commonbookings_additional_features_setting_section' // section
        );
        add_settings_field(
            'buchung_historie_1', // id
            'Buchungshistorie', // title
            [$this, 'buchung_historie_1_callback'], // callback
            'commonbookings-additional-features-admin', // page
            'commonbookings_additional_features_setting_section' // section
        );

        add_settings_field(
            'profil_2', // id
            'mein Profil', // title
            [$this, 'profil_2_callback'], // callback
            'commonbookings-additional-features-admin', // page
            'commonbookings_additional_features_setting_section' // section
        );
        add_settings_field(
            'konto_3', // id
            'mein Konto', // title
            [$this, 'konto_3_callback'], // callback
            'commonbookings-additional-features-admin', // page
            'commonbookings_additional_features_setting_section' // section
        );
    }

    public function commonbookings_additional_features_blacklist_1_section_info()
    {
        ?>
        <hr>
        <p>Hier kann festgelegt werden, wie oft ein <strong>Artikel</strong> von einer Person im festgelegten Interval
            gebucht werden kann. Alle weiteren
            Buchungen werden automatisch abgelehent. Bei Ablehnung wird eine E-Mail erzeugt, die dem Nutzer mitteilt,
            dass seine Buchung wegen zu häufiger
            Buchung storniert wurde.</p>
        <?php
    }

    public function commonbookings_additional_features_blacklist_2_section_info()
    {
        ?>
        <hr>
        <p>Hier kann festgelegt werden, wie oft <strong>an einer Station</strong> von einer Person im festgelegten
            Interval gebucht werden kann. Alle weiteren
            Buchungen werden automatisch abgelehent. Bei Ablehnung wird eine E-Mail erzeugt, die dem Nutzer mitteilt,
            dass seine Buchung wegen zu häufiger
            Buchung storniert wurde.</p>
        <?php
    }

    public function commonbookings_additional_features_blacklist_3_section_info()
    {
        ?>
        <hr>
        <p>Hier kann festgelegt werden, wie oft <strong>generell</strong> von einer Person im festgelegten Interval
            gebucht werden kann. Alle weiteren Buchungen
            werden automatisch abgelehent. Bei Ablehnung wird eine E-Mail erzeugt, die dem Nutzer mitteilt, dass seine
            Buchung wegen zu häufiger Buchung
            storniert wurde.</p>
        <?php
    }

    public function commonbookings_additional_features_blacklist_4_section_info()
    {
        ?>
        <hr>
        <p>Hier kann der Text der E-Mail festgelegt werden.</p>
        <?php
    }

    public function commonbookings_additional_features_blacklist_5_section_info()
    {
        ?>
        <hr>
        <p>Dieser Text wird Nutzer:innen angezeigt, wenn eine Buchung aufgrund der Blacklist-Regeln nicht möglich ist.</p>
        <?php
    }

    public function commonbookings_additional_features_blacklist_section_info()
    {
        ?>
        <div class="my-3"></div>
        <?php
    }


    public function commonbookings_additional_features_blacklist_init()
    {
        register_setting(
            'commonbookings_additional_features_blacklist_group', // option_group
            'commonbookings_additional_features_option_blacklist', // option_name
            [$this, 'commonbookings_additional_features_blacklist_sanitize'] // sanitize_callback
        );
        add_settings_section(
            'commonbookings_additional_features_setting_blacklist_section', // id
            'Blacklist', // title
            [$this, 'commonbookings_additional_features_blacklist_section_info'], // callback
            'commonbookings-additional-features-blacklist' // page
        );
        add_settings_section(
            'commonbookings_additional_features_setting_blacklist_1_section', // id
            'Artikel', // title
            [$this, 'commonbookings_additional_features_blacklist_1_section_info'], // callback
            'commonbookings-additional-features-blacklist' // page
        );
        add_settings_field(
            'blacklist_item_active', // id
            'Aktiviere Artikel Buchungen', // title
            [$this, 'blacklist_item_active_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_1_section' // section
        );
        add_settings_field(
            'blacklist_item', // id
            'Anzahl Artikel Buchungen', // title
            [$this, 'blacklist_item_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_1_section' // section
        );
        add_settings_field(
            'blacklist_item_interval', // id
            'Interval (Tage)', // title
            [$this, 'blacklist_item_interval_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_1_section' // section
        );
        add_settings_field(
            'blacklist_item_include_admins', // id
            'Auch Artikel-Admins prüfen', // title
            [$this, 'blacklist_item_include_admins_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_1_section' // section
        );
        add_settings_section(
            'commonbookings_additional_features_setting_blacklist_2_section', // id
            'Standort', // title
            [$this, 'commonbookings_additional_features_blacklist_2_section_info'], // callback
            'commonbookings-additional-features-blacklist' // page
        );
        add_settings_field(
            'blacklist_location_active', // id
            'Aktiviere Standort Buchungen', // title
            [$this, 'blacklist_location_active_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_2_section' // section
        );
        add_settings_field(
            'blacklist_location', // id
            'Anzahl Standort Buchungen', // title
            [$this, 'blacklist_location_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_2_section' // section
        );
        add_settings_field(
            'blacklist_location_interval', // id
            'Interval (Tage)', // title
            [$this, 'blacklist_location_interval_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_2_section' // section
        );
        add_settings_field(
            'blacklist_location_include_admins', // id
            'Auch Stations-Admins prüfen', // title
            [$this, 'blacklist_location_include_admins_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_2_section' // section
        );
        add_settings_section(
            'commonbookings_additional_features_setting_blacklist_3_section', // id
            'Buchungen', // title
            [$this, 'commonbookings_additional_features_blacklist_3_section_info'], // callback
            'commonbookings-additional-features-blacklist' // page
        );
        add_settings_field(
            'blacklist_global_active', // id
            'Aktiviere Buchungen', // title
            [$this, 'blacklist_global_active_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_3_section' // section
        );
        add_settings_field(
            'blacklist_global', // id
            'Anzahl Buchungen', // title
            [$this, 'blacklist_global_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_3_section' // section
        );
        add_settings_field(
            'blacklist_global_interval', // id
            'Interval (Tage)', // title
            [$this, 'blacklist_global_interval_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_3_section' // section
        );
        add_settings_field(
            'blacklist_global_include_admins', // id
            'Auch Global-Admins prüfen', // title
            [$this, 'blacklist_global_include_admins_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_3_section' // section
        );
        add_settings_section(
            'commonbookings_additional_features_setting_blacklist_4_section', // id
            'E-Mail', // title
            [$this, 'commonbookings_additional_features_blacklist_4_section_info'], // callback
            'commonbookings-additional-features-blacklist' // page
        );
        add_settings_field(
            'blacklist_email_bcc', // id
            'Blindkopie', // title
            [$this, 'blacklist_email_bcc_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_4_section' // section
        );
        add_settings_field(
            'blacklist_email_subject', // id
            'Betreff', // title
            [$this, 'blacklist_email_subject_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_4_section' // section
        );
        add_settings_field(
            'blacklist_email_text', // id
            'E-Mail-Text', // title
            [$this, 'blacklist_email_text_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_4_section' // section
        );
        add_settings_section(
            'commonbookings_additional_features_setting_blacklist_5_section', // id
            'Frontend Hinweis', // title
            [$this, 'commonbookings_additional_features_blacklist_5_section_info'], // callback
            'commonbookings-additional-features-blacklist' // page
        );
        add_settings_field(
            'blacklist_notice_text', // id
            'Hinweistext', // title
            [$this, 'blacklist_notice_text_callback'], // callback
            'commonbookings-additional-features-blacklist', // page
            'commonbookings_additional_features_setting_blacklist_5_section' // section
        );
    }

    public function commonbookings_additional_features_qrcode_init()
    {
        register_setting(
            'commonbookings_additional_features_qrcode_group', // option_group
            'commonbookings_additional_features_option_qrcode', // option_name
            [$this, 'commonbookings_additional_features_qrcode_sanitize'] // sanitize_callback
        );

        add_settings_section(
            'commonbookings_additional_features_setting_qrcode_section', // id
            'QR-Code Versand', // title
            [$this, 'commonbookings_additional_features_qrcode_section_info'], // callback
            'commonbookings-additional-features-qrcode' // page
        );

        add_settings_field(
            'qrcode_enabled', // id
            'QR-Code Versand aktivieren', // title
            [$this, 'qrcode_enabled_callback'], // callback
            'commonbookings-additional-features-qrcode', // page
            'commonbookings_additional_features_setting_qrcode_section' // section
        );
    }

    public function commonbookings_additional_features_qrcode_section_info()
    {
        ?>
        <p>Wenn aktiviert, wird der QR-Code in Bestätigungs-E-Mails eingefügt und eine Prüfen-Seite erstellt.</p>
        <?php
    }

    public function qrcode_enabled_callback()
    {
        $option = isset($this->commonbookings_additional_features_qrcode['qrcode_enabled']) ? $this->commonbookings_additional_features_qrcode['qrcode_enabled'] : false;
        echo '<input type="checkbox" name="commonbookings_additional_features_option_qrcode[qrcode_enabled]" value="1" ' . checked($option, 1, false) . ' />';
    }

    public function commonbookings_additional_features_qrcode_sanitize($input)
    {
        $sanitary_values = [];
        $sanitary_values['qrcode_enabled'] = !empty($input['qrcode_enabled']) ? 1 : 0;

        return $sanitary_values;
    }

    public function commonbookings_additional_features_sanitize($input)
    {
        $sanitary_values = [];
        if (isset($input['werbung_0'])) {
            $sanitary_values['werbung_0'] = $input['werbung_0'];
        }
        if (isset($input['buchung_0'])) {
            $sanitary_values['buchung_0'] = $input['buchung_0'];
        }
        if (isset($input['buchung_historie_1'])) {
            $sanitary_values['buchung_historie_1'] =
                $input['buchung_historie_1'];
        }
        if (isset($input['profil_2'])) {
            $sanitary_values['profil_2'] = $input['profil_2'];
        }
        if (isset($input['konto_3'])) {
            $sanitary_values['konto_3'] = $input['konto_3'];
        }
        return $sanitary_values;
    }

    public function commonbookings_additional_features_blacklist_sanitize($input)
    {
        $sanitary_values = [];
        if (isset($input['blacklist_item_active'])) {
            $sanitary_values['blacklist_item_active'] = $input['blacklist_item_active'];
        }
        if (isset($input['blacklist_item_interval'])) {
            $sanitary_values['blacklist_item_interval'] = $input['blacklist_item_interval'];
        }
        if (isset($input['blacklist_item'])) {
            $sanitary_values['blacklist_item'] = $input['blacklist_item'];
        }
        if (isset($input['blacklist_item_include_admins'])) {
            $sanitary_values['blacklist_item_include_admins'] = $input['blacklist_item_include_admins'];
        }
        if (isset($input['blacklist_location_active'])) {
            $sanitary_values['blacklist_location_active'] = $input['blacklist_location_active'];
        }
        if (isset($input['blacklist_location_interval'])) {
            $sanitary_values['blacklist_location_interval'] = $input['blacklist_location_interval'];
        }
        if (isset($input['blacklist_location'])) {
            $sanitary_values['blacklist_location'] = $input['blacklist_location'];
        }
        if (isset($input['blacklist_location_include_admins'])) {
            $sanitary_values['blacklist_location_include_admins'] = $input['blacklist_location_include_admins'];
        }
        if (isset($input['blacklist_global_active'])) {
            $sanitary_values['blacklist_global_active'] = $input['blacklist_global_active'];
        }
        if (isset($input['blacklist_global_interval'])) {
            $sanitary_values['blacklist_global_interval'] = $input['blacklist_global_interval'];
        }
        if (isset($input['blacklist_global'])) {
            $sanitary_values['blacklist_global'] = $input['blacklist_global'];
        }
        if (isset($input['blacklist_global_include_admins'])) {
            $sanitary_values['blacklist_global_include_admins'] = $input['blacklist_global_include_admins'];
        }
        if (isset($input['blacklist_email_bcc'])) {
            $sanitary_values['blacklist_email_bcc'] = $input['blacklist_email_bcc'];
        }
        if (isset($input['blacklist_email_text'])) {
            $sanitary_values['blacklist_email_text'] = $input['blacklist_email_text'];
        }
        if (isset($input['blacklist_email_subject'])) {
            $sanitary_values['blacklist_email_subject'] = $input['blacklist_email_subject'];
        }
        if (isset($input['blacklist_notice_text'])) {
            $sanitary_values['blacklist_notice_text'] = wp_kses_post($input['blacklist_notice_text']);
        }
        return $sanitary_values;
    }

    public function commonbookings_additional_features_section_info()
    {
    }

    public function blacklist_item_callback()
    {
        printf(
            '<input type="number"  name="commonbookings_additional_features_option_blacklist[blacklist_item]" id="blacklist_item" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_item']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_item']
            )
                : ''
        );
    }

    public function blacklist_item_interval_callback()
    {
        printf(
            '<input type="number"  name="commonbookings_additional_features_option_blacklist[blacklist_item_interval]" id="blacklist_item_interval" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_item_interval']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_item_interval']
            )
                : ''
        );
    }

    public function blacklist_item_active_callback()
    {
        $option = isset($this->commonbookings_additional_features_blacklist['blacklist_item_active']) ? $this->commonbookings_additional_features_blacklist['blacklist_item_active'] : false;
        echo '<input type="checkbox" name="commonbookings_additional_features_option_blacklist[blacklist_item_active]" value="1" ' . checked($option, 1, false) . ' />';
    }

    public function blacklist_item_include_admins_callback()
    {
        $option = isset($this->commonbookings_additional_features_blacklist['blacklist_item_include_admins']) ? $this->commonbookings_additional_features_blacklist['blacklist_item_include_admins'] : false;
        echo '<input type="checkbox" name="commonbookings_additional_features_option_blacklist[blacklist_item_include_admins]" value="1" ' . checked($option, 1, false) . ' />';
    }

    public function blacklist_global_callback()
    {
        printf(
            '<input type="number"  name="commonbookings_additional_features_option_blacklist[blacklist_global]" id="blacklist_global" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_global']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_global']
            )
                : ''
        );
    }

    public function blacklist_global_interval_callback()
    {
        printf(
            '<input type="number"  name="commonbookings_additional_features_option_blacklist[blacklist_global_interval]" id="blacklist_global_interval" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_global_interval']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_global_interval']
            )
                : ''
        );
    }

    public function blacklist_global_active_callback()
    {
        $option = isset($this->commonbookings_additional_features_blacklist['blacklist_global_active']) ? $this->commonbookings_additional_features_blacklist['blacklist_global_active'] : false;
        echo '<input type="checkbox" name="commonbookings_additional_features_option_blacklist[blacklist_global_active]" value="1" ' . checked($option, 1, false) . ' />';
    }

    public function blacklist_global_include_admins_callback()
    {
        $option = isset($this->commonbookings_additional_features_blacklist['blacklist_global_include_admins']) ? $this->commonbookings_additional_features_blacklist['blacklist_global_include_admins'] : false;
        echo '<input type="checkbox" name="commonbookings_additional_features_option_blacklist[blacklist_global_include_admins]" value="1" ' . checked($option, 1, false) . ' />';
    }

    public function blacklist_location_callback()
    {
        printf(
            '<input type="number"  name="commonbookings_additional_features_option_blacklist[blacklist_location]" id="blacklist_location" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_location']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_location']
            )
                : ''
        );
    }

    public function blacklist_location_interval_callback()
    {
        printf(
            '<input type="number"  name="commonbookings_additional_features_option_blacklist[blacklist_location_interval]" id="blacklist_location_interval" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_location_interval']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_location_interval']
            )
                : ''
        );
    }

    public function blacklist_location_active_callback()
    {
        $option = isset($this->commonbookings_additional_features_blacklist['blacklist_location_active']) ? $this->commonbookings_additional_features_blacklist['blacklist_location_active'] : false;
        echo '<input type="checkbox" name="commonbookings_additional_features_option_blacklist[blacklist_location_active]" value="1" ' . checked($option, 1, false) . ' />';
    }

    public function blacklist_location_include_admins_callback()
    {
        $option = isset($this->commonbookings_additional_features_blacklist['blacklist_location_include_admins']) ? $this->commonbookings_additional_features_blacklist['blacklist_location_include_admins'] : false;
        echo '<input type="checkbox" name="commonbookings_additional_features_option_blacklist[blacklist_location_include_admins]" value="1" ' . checked($option, 1, false) . ' />';
    }

    public function blacklist_email_subject_callback()
    {
        printf(
            '<input type="text"  name="commonbookings_additional_features_option_blacklist[blacklist_email_subject]" id="blacklist_email_subject" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_email_subject']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_email_subject']
            )
                : 'Buchung storniert: {{item:post_title}} am Standort {{location:post_title}} {{booking:formattedBookingDate}}'
        );
    }

    public function blacklist_email_bcc_callback()
    {
        printf(
            '<input type="text"  name="commonbookings_additional_features_option_blacklist[blacklist_email_bcc]" id="blacklist_email_bcc" value="%s" />',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_email_bcc']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_email_bcc']
            )
                : ''
        );
    }

    public function blacklist_email_text_callback()
    {
        printf(
            '<p>Die Benutzung von CommonBookings Template Tags ist möglich: <a href="https://commonsbooking.org/docs/einstellungen/template-tags/" target="_blank">Dokumentation</a></p><textarea class="large-text" rows="5" name="commonbookings_additional_features_option_blacklist[blacklist_email_text]" id="blacklist_email_text">%s</textarea>',
            isset(
                $this->commonbookings_additional_features_blacklist['blacklist_email_text']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_blacklist['blacklist_email_text']
            )
                : 'Hallo {{user:first_name}},<br>
                <br>
                Deine Buchung von {{item:post_title}} am Standort {{location:post_title}} {{booking:formattedBookingDate}} wurde automatisch storniert.<br>
                Du hast leider in letzter Zeit zu oft gebucht!
                <br>
                Bei Rückfragen stehen wir dir gerne zur Verfügung.
                <br>
                {{booking:getEmailSignature}}'
        );
    }

    public function blacklist_notice_text_callback()
    {
        $value = isset($this->commonbookings_additional_features_blacklist['blacklist_notice_text'])
            ? $this->commonbookings_additional_features_blacklist['blacklist_notice_text']
            : BlacklistSettings::getDefaultNoticeText();

        printf(
            '<p>Verfügbare Platzhalter: <code>{{reason}}</code>, <code>{{limit}}</code>, <code>{{interval}}</code>.</p><textarea class="large-text" rows="3" name="commonbookings_additional_features_option_blacklist[blacklist_notice_text]" id="blacklist_notice_text">%s</textarea>',
            esc_textarea($value)
        );
    }

    private function getBlacklistReasonLabels(): array
    {
        return [
            'item' => __('Artikel', 'cb-additional-features'),
            'location' => __('Standort', 'cb-additional-features'),
            'global' => __('Buchung', 'cb-additional-features'),
        ];
    }

    public function werbung_0_callback()
    {
        printf(
            '<textarea class="large-text" rows="5" name="commonbookings_additional_features_option_name[werbung_0]" id="werbung_0">%s</textarea>',
            isset(
                $this->commonbookings_additional_features_options['werbung_0']
            )
                ? esc_attr(
                $this->commonbookings_additional_features_options['werbung_0']
            )
                : ''
        );
    }

    public function common_bookings_additional_features_create_blacklist_page()
    {
        $this->commonbookings_additional_features_blacklist = get_option('commonbookings_additional_features_option_blacklist');
        $logEntries = BlacklistLog::getRecentEntries(100);
        $stats = BlacklistLog::getStats();
        $reasonMap = $this->getBlacklistReasonLabels();

        if (!empty($stats)) {
            uasort($stats, function ($a, $b) {
                return $b['total'] <=> $a['total'];
            });
        }
        ?>
        <div class="wrap">
            <h1>CommonBookings Additional Features</h1>
            <hr>
            <form method="post" action="options.php">
                <?php
                settings_fields('commonbookings_additional_features_blacklist_group');
                do_settings_sections('commonbookings-additional-features-blacklist');
                submit_button();
                ?>
            </form>
            <?php
            if ($logEntries) {
                ?>
                <h3 class="mt-5">Historie</h3>
                <div id="list-container" class="rounded border border-dark" style="max-height: 400px;overflow-y: auto;">
                    <table class="widefat striped">
                        <thead>
                        <tr>
                            <th><?php esc_html_e('Nutzer', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('E-Mail', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Artikel', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Standort', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Zeitraum', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Versuch', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Grund', 'cb-additional-features'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($logEntries as $entry) :
                            $user = isset($entry['user_id']) ? get_userdata($entry['user_id']) : null;
                            $userName = $user
                                ? trim($user->first_name . ' ' . $user->last_name) . ' (' . $user->user_login . ')'
                                : sprintf(__('Nutzer #%d', 'cb-additional-features'), intval($entry['user_id'] ?? 0));
                            $userEmail = $user ? $user->user_email : '–';
                            $itemTitle = isset($entry['item_id']) && $entry['item_id'] ? get_the_title($entry['item_id']) : '–';
                            $locationTitle = isset($entry['location_id']) && $entry['location_id'] ? get_the_title($entry['location_id']) : '–';
                            $start = isset($entry['start']) ? intval($entry['start']) : 0;
                            $end = isset($entry['end']) ? intval($entry['end']) : 0;
                            $period = $start && $end ? date_i18n('d.m.', $start) . ' - ' . date_i18n('d.m.Y', $end) : '–';
                            $attempt = isset($entry['timestamp']) && $entry['timestamp'] ? date_i18n('d.m.Y H:i', $entry['timestamp']) : '–';
                            $reasonKey = $entry['rule'] ?? '';
                            $reasonLabel = $reasonMap[$reasonKey] ?? __('Unbekannt', 'cb-additional-features');
                            ?>
                            <tr>
                                <td><?php echo esc_html($userName); ?></td>
                                <td><?php echo esc_html($userEmail); ?></td>
                                <td><?php echo esc_html($itemTitle ?: '–'); ?></td>
                                <td><?php echo esc_html($locationTitle ?: '–'); ?></td>
                                <td><?php echo esc_html($period); ?></td>
                                <td><?php echo esc_html($attempt); ?></td>
                                <td><?php echo esc_html($reasonLabel); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php } else { ?>
                <p><?php esc_html_e('Es liegen noch keine Blacklist-Einträge vor.', 'cb-additional-features'); ?></p>
            <?php } ?>

            <h3 class="mt-5">Statistik</h3>
            <?php if ($stats) : ?>
                <div class="rounded border border-dark" style="max-height: 400px;overflow-y: auto;">
                    <table class="widefat striped">
                        <thead>
                        <tr>
                            <th><?php esc_html_e('Nutzer', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Gesamt', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Artikel', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Standort', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Global', 'cb-additional-features'); ?></th>
                            <th><?php esc_html_e('Letzter Versuch', 'cb-additional-features'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($stats as $userId => $data) :
                            $user = $userId ? get_userdata($userId) : null;
                            $userName = $user
                                ? trim($user->first_name . ' ' . $user->last_name) . ' (' . $user->user_login . ')'
                                : sprintf(__('Nutzer #%d', 'cb-additional-features'), intval($userId));
                            $lastAttempt = $data['last_attempt'] ? date_i18n('d.m.Y H:i', $data['last_attempt']) : '–';
                            ?>
                            <tr>
                                <td><?php echo esc_html($userName); ?></td>
                                <td><?php echo esc_html($data['total']); ?></td>
                                <td><?php echo esc_html($data['rules']['item'] ?? 0); ?></td>
                                <td><?php echo esc_html($data['rules']['location'] ?? 0); ?></td>
                                <td><?php echo esc_html($data['rules']['global'] ?? 0); ?></td>
                                <td><?php echo esc_html($lastAttempt); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else : ?>
                <p><?php esc_html_e('Es sind noch keine statistischen Daten vorhanden.', 'cb-additional-features'); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }

    public function common_bookings_additional_features_create_qrcode_page()
    {
        $this->commonbookings_additional_features_qrcode = get_option('commonbookings_additional_features_option_qrcode');
        ?>
        <div class="wrap">
            <h1>CommonBookings Additional Features</h1>
            <hr>
            <form method="post" action="options.php">
                <?php
                settings_fields('commonbookings_additional_features_qrcode_group');
                do_settings_sections('commonbookings-additional-features-qrcode');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function common_bookings_additional_features_create_timeframe_page()
    {
        if (isset($_SESSION['error']) && $_SESSION['error']) {
            $error = $_SESSION['error'];
            session_destroy();
        } else {
            $error = '';
        }
        if (isset($_SESSION['success']) && $_SESSION['success']) {
            $success = $_SESSION['success'];
            session_destroy();
        } else {
            $success = '';
        }
        $locations = Location::get();
        echo TemplateLoader::load()->render('holidays.html.twig', [
            'admin_post_url' => admin_url('admin-post.php'),
            'submit' => get_submit_button('Feiertage hinzufügen', 'primary large', 'add_holiday', false),
            'delete' => get_submit_button('Feiertage löschen', 'secondary large', 'remove_holiday', false),
            'nonce_field' => wp_nonce_field(
                'add_holiday',
                'holiday_nonce',
                false
            ),
            'timeframes' => $locations,
            'error' => $error,
            'success' => $success,
        ]);
    }

    public function additional_create_sidebar_page()
    {
        $this->commonbookings_additional_features_options = get_option('commonbookings_additional_features_option_name'); ?>

        <div class="wrap">
            <h2>Sidebar</h2>
            <hr>
            <?php settings_errors(); ?>

            <form method="post" action="options.php">
                <?php
                settings_fields('additional_option_group');
                do_settings_sections('additional-admin');
                submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function buchung_0_callback()
    {
        ?>
        <p>Die Seite auf der der Shortcode "[cbaf_bookings]" aufgerufen wird. Dies gibt eine Übersicht über die
            getätigten
            Buchungen.</p>
        <select name="commonbookings_additional_features_option_name[buchung_0]" id="buchung_0">
            <?php
            $args = [
                'sort_order' => 'asc',
                'sort_column' => 'post_title',
                'hierarchical' => 1,
                'exclude' => '',
                'include' => '',
                'meta_key' => '',
                'meta_value' => '',
                'authors' => '',
                'child_of' => 0,
                'parent' => -1,
                'exclude_tree' => '',
                'number' => '',
                'offset' => 0,
                'post_type' => 'page',
                'post_status' => 'publish',
            ];
            $pages = get_pages($args);
            foreach ($pages as $page) {
                $selected =
                    isset($this->commonbookings_additional_features_options) &&
                    $this->commonbookings_additional_features_options['buchung_0'] ==
                    $page->ID
                        ? 'selected'
                        : ''; ?>
                <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo get_the_title(
                        $page->ID
                    ); ?>
                </option>
                <?php
            } ?>

        </select> <?php
    }

    public function buchung_historie_1_callback()
    {
        ?>
        <p>Die Seite auf der der Shortcode "[cbaf_historie_table]" aufgerufen wird. Dies gibt eine Übersicht über die
            vergangene
            Buchungen.</p>
        <select name="commonbookings_additional_features_option_name[buchung_historie_1]" id="buchung_historie_1">
            <?php
            $args = [
                'sort_order' => 'asc',
                'sort_column' => 'post_title',
                'hierarchical' => 1,
                'exclude' => '',
                'include' => '',
                'meta_key' => '',
                'meta_value' => '',
                'authors' => '',
                'child_of' => 0,
                'parent' => -1,
                'exclude_tree' => '',
                'number' => '',
                'offset' => 0,
                'post_type' => 'page',
                'post_status' => 'publish',
            ];
            $pages = get_pages($args);
            foreach ($pages as $page) {
                $selected =
                    isset($this->commonbookings_additional_features_options) &&
                    $this->commonbookings_additional_features_options['buchung_historie_1'] == $page->ID
                        ? 'selected'
                        : ''; ?>
                <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo get_the_title(
                        $page->ID
                    ); ?>
                </option>
                <?php
            } ?>

        </select> <?php
    }

    public function profil_2_callback()
    {
        ?>
        <p>Falls ein Plugin die Profilbearbeitung übernimmt, kann hier die Seite eingestellt werden auf der die
            Profildaten
            geändert werden können.</p>
        <select name="commonbookings_additional_features_option_name[profil_2]" id="profil_2">
            <?php $selected =
                isset($this->commonbookings_additional_features_options) &&
                $this->commonbookings_additional_features_options['profil_2'] == '-1'
                    ? 'selected'
                    : ''; ?>
            <option value="-1" <?php echo $selected; ?>>Standard (WP-Profil)
            </option>
            <?php
            $args = [
                'sort_order' => 'asc',
                'sort_column' => 'post_title',
                'hierarchical' => 1,
                'exclude' => '',
                'include' => '',
                'meta_key' => '',
                'meta_value' => '',
                'authors' => '',
                'child_of' => 0,
                'parent' => -1,
                'exclude_tree' => '',
                'number' => '',
                'offset' => 0,
                'post_type' => 'page',
                'post_status' => 'publish',
            ];
            $pages = get_pages($args);
            foreach ($pages as $page) {
                $selected =
                    isset($this->commonbookings_additional_features_options) &&
                    $this->commonbookings_additional_features_options['profil_2'] ==
                    $page->ID
                        ? 'selected'
                        : ''; ?>
                <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo get_the_title(
                        $page->ID
                    ); ?>
                </option>
                <?php
            } ?>

        </select> <?php
    }

    public function konto_3_callback()
    {
        ?>
        <p>Falls ein Plugin die Profilbearbeitung übernimmt, kann hier die Seite eingestellt werden auf der die
            Profildaten
            geändert werden können.</p>
        <select name="commonbookings_additional_features_option_name[konto_3]" id="konto_3">
            <?php $selected =
                isset($this->commonbookings_additional_features_options) &&
                $this->commonbookings_additional_features_options['konto_3'] == '-1'
                    ? 'selected'
                    : ''; ?>
            <option value="-1" <?php echo $selected; ?>>ausblenden
            </option>
            <?php
            $args = [
                'sort_order' => 'asc',
                'sort_column' => 'post_title',
                'hierarchical' => 1,
                'exclude' => '',
                'include' => '',
                'meta_key' => '',
                'meta_value' => '',
                'authors' => '',
                'child_of' => 0,
                'parent' => -1,
                'exclude_tree' => '',
                'number' => '',
                'offset' => 0,
                'post_type' => 'page',
                'post_status' => 'publish',
            ];
            $pages = get_pages($args);
            foreach ($pages as $page) {
                $selected =
                    isset($this->commonbookings_additional_features_options) &&
                    $this->commonbookings_additional_features_options['konto_3'] ==
                    $page->ID
                        ? 'selected'
                        : ''; ?>
                <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo get_the_title(
                        $page->ID
                    ); ?>
                </option>
                <?php
            } ?>

        </select> <?php
    }


    public function common_bookings_additional_features_create_statistik_page()
    {
        ?>
        <script>
            function openTab(evt, cityName) {
                // Declare all variables
                var i, tabcontent, tablinks;

                // Get all elements with class="tabcontent" and hide them
                tabcontent = document.getElementsByClassName("tabcontent");
                for (i = 0; i < tabcontent.length; i++) {
                    tabcontent[i].style.display = "none";
                }

                // Get all elements with class="tablinks" and remove the class "active"
                tablinks = document.getElementsByClassName("tablinks");
                for (i = 0; i < tablinks.length; i++) {
                    tablinks[i].className = tablinks[i].className.replace(" active", "");
                }

                // Show the current tab, and add an "active" class to the button that opened the tab
                document.getElementById(cityName).style.display = "block";
                evt.currentTarget.className += " active";
            }
        </script>
        <div class="wrap">
            <h2>Statistik</h2>
            <hr>
            <p>
                Hier gibts die Statistik. Der Download dauert circa eine Minute. Bitte warten. Bereinigte Nutzerdaten
                bedeutet: Nutzer, die sich innerhalb der letzten 2 Jahre eingeloggt haben.
                <?php
                ?>
            </p>
            <form method="post" action="">
                <?php
                if (isset($_POST['generate_excel'])) {
                    generate_excel();
                }
                ?>
                <input type="submit" name="generate_excel" class="button button-primary" value="Excel downloaden">
            </form>

        </div>


        <?php
    }

    private function calculateBookingDuration($startDate, $endDate): float
    {
        return ceil(($endDate - $startDate) / (60 * 60 * 24));
    }



    private function getCanceledPosts()
    {
        if (!isset($this->cache['getCanceledPosts'])) {
            $args = array(
                'post_type' => CustomPostTypeBooking::$postType, // Ändere dies, wenn du nach einem anderen Post-Typ suchen möchtest
                'posts_per_page' => -1,
                'post_status' => 'canceled', // Anzahl der zurückgegebenen Beiträge (-1 für alle Beiträge)
                'meta_key' => 'repetition-start', // Add meta key to sort by
                'orderby' => 'meta_value_num', // Sort by meta value as a number
                'order' => 'DESC',
            );
            $query = new \WP_Query($args);
            $this->cache['getCanceledPosts'] = $query->posts;
        }
        return $this->cache['getCanceledPosts'];
    }





    function commonbookings_additional_features_generate_excel()
    {
        if (isset($_POST['generate_excel'])) {
            $this->generate_and_stream_excel();
        }
    }

    /**
     * @throws Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
     */
    function generate_and_stream_excel($output = true)
    {

        if (!get_transient('common_bookings_additional_features_create_user_data')) {
            (new UserStatistik())->getUserStat();
        }
        if(!get_transient('common_bookings_additional_features_create_confirmed_posts')){
            (new ConfirmedPosts())->getConfirmedPosts();
        }

        $bookings = get_transient('common_bookings_additional_features_create_confirmed_posts');
        $monthlyStatistics =   get_transient('common_bookings_additional_features_create_user_stat');


            $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
            // Add data and formatting to the spreadsheet
            $sheet = $spreadsheet->getActiveSheet();
            $sheet->setTitle("Nutzer");
            $white = new Color(Color::COLOR_WHITE);
            $black = new Color(Color::COLOR_BLACK);
            $darkgrey = new Color("FF444444");
            $sheet->setCellValue([1, 1], 'Monat');
            $sheet->getStyle([1, 1])->getFont()->setBold(true);
            $sheet->getStyle([1, 1])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle([1, 1])->getFont()->setColor($white);
            $sheet->getStyle([1, 1])->getFill()->setFillType(Fill::FILL_SOLID);
            $sheet->getStyle([1, 1])->getFill()->setStartColor($black);

            $sheet->setCellValue([2, 1], 'Gesamtanzahl');
            $sheet->getStyle([2, 1])->getFont()->setBold(true);
            $sheet->getStyle([2, 1])->getFont()->setColor($white);
            $sheet->getStyle([2, 1])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle([2, 1])->getFill()->setFillType(Fill::FILL_SOLID);
            $sheet->getStyle([2, 1])->getFill()->setStartColor($black);
            $sheet->setCellValue([3, 1], 'Anstieg');
            $sheet->getStyle([3, 1])->getFont()->setBold(true);
            $sheet->getStyle([3, 1])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle([3, 1])->getFont()->setColor($white);
            $sheet->getStyle([3, 1])->getFill()->setFillType(Fill::FILL_SOLID);
            $sheet->getStyle([3, 1])->getFill()->setStartColor($black);
            $sheet->setCellValue([4, 1], 'bereinigte Gesamtanzahl');
            $sheet->getStyle([4, 1])->getFont()->setBold(true);
            $sheet->getStyle([4, 1])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle([4, 1])->getFont()->setColor($white);
            $sheet->getStyle([4, 1])->getFill()->setFillType(Fill::FILL_SOLID);
            $sheet->getStyle([4, 1])->getFill()->setStartColor($black);
            $sheet->setCellValue([5, 1], 'bereinigter Anstieg');
            $sheet->getStyle([5, 1])->getFont()->setBold(true);
            $sheet->getStyle([5, 1])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle([5, 1])->getFont()->setColor($white);
            $sheet->getStyle([5, 1])->getFill()->setFillType(Fill::FILL_SOLID);
            $sheet->getStyle([5, 1])->getFill()->setStartColor($black);
            $row = 2;
            $lastMonth = "";
            foreach ($monthlyStatistics as $monthYear => $stats) {
                if (!str_contains($lastMonth, substr($monthYear, -4))) {
                    $sheet->setCellValue([1, $row], substr($monthYear, -4));
                    $sheet->getStyle([1, $row])->getFont()->setBold(true);
                    $sheet->getStyle([1, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $sheet->getStyle([1, $row])->getFont()->setColor($white);
                    $sheet->getStyle([1, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                    $sheet->getStyle([1, $row])->getFill()->setStartColor($darkgrey);
                    $sheet->mergeCells([1, $row, 5, $row]);
                    $row++;
                }
                $lastMonth = $monthYear;
                $sheet->setCellValue([1, $row], substr($monthYear, 0, -5));
                $sheet->getStyle([1, $row])->getFont()->setBold(true);
                $sheet->getStyle([1, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->getStyle([1, $row])->getFont()->setColor($white);
                $sheet->getStyle([1, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $sheet->getStyle([1, $row])->getFill()->setStartColor($darkgrey);
                $sheet->setCellValue([2, $row], $stats['registered_users']);
                $sheet->getStyle([2, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->setCellValue([3, $row], $stats['increase']);
                $sheet->getStyle([3, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->setCellValue([4, $row], $stats['cleanup_total']);
                $sheet->getStyle([4, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $sheet->setCellValue([5, $row], $stats['cleaned_up_increase']);
                $sheet->getStyle([5, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $row++;
            }

            foreach ($sheet->getColumnIterator() as $column) {
                $sheet->getColumnDimension($column->getColumnIndex())->setAutoSize(true);
            }

            // Gruppiere Buchungen nach Item
            $bookingsByItem = [];
            foreach ($bookings as $booking) {
                $item = $booking['item'];
                $bookingsByItem[$item][] = $booking;
            }

            usort($bookingsByItem, function ($item1, $item2) {
                // Use strcasecmp for case-insensitive comparison
                return strcasecmp($item1[0]['itemName'], $item2[0]['itemName']);
            });


            // Ausgabe der Tabellen
            foreach ($bookingsByItem as $item => $itemBookings) {
                $worksheet = $spreadsheet->createSheet();
                $name = str_replace(":", "", $itemBookings[0]['itemName']);
                $parts = explode(" - ", $name);

                if (strlen($parts[0]) > 30) {
                    $short = explode(" ", $parts[0]);
                    $parts[0] = $short[0];
                }
                $worksheet->setTitle($parts[0]);

                $worksheet->setCellValue([1, 1], $itemBookings[0]['itemName']);
                $worksheet->getStyle([1, 1])->getFont()->setBold(true);
                $worksheet->getStyle([1, 1])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([1, 1])->getFont()->setColor($white);
                $worksheet->getStyle([1, 1])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([1, 1])->getFill()->setStartColor($black);
                $worksheet->mergeCells([1, 1, 9, 1]);
                $row = 2;
                $column = 1;

                $worksheet->setCellValue([$column, $row], 'Monat');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], 'Buchungen im Monat');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], 'Verschiedene Nutzer');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], '1-Tages Buchungen');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], '2-Tages Buchungen');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], '3-Tages Buchungen');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], '4-Tages Buchungen');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], '5-Tages Buchungen');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);
                $column++;

                $worksheet->setCellValue([$column, $row], 'Gesamtbuchungstage');
                $worksheet->getStyle([$column, $row])->getFont()->setBold(true);
                $worksheet->getStyle([$column, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                $worksheet->getStyle([$column, $row])->getFont()->setColor($white);
                $worksheet->getStyle([$column, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                $worksheet->getStyle([$column, $row])->getFill()->setStartColor($black);

                $row++;
                $column = 1;

                $monthsData = [];
                $yearData = [];
                // Daten für jede Buchung sammeln
                foreach ($itemBookings as $booking) {
                    $month = date('F Y', $booking['startDate']);
                    $year = date('Y', $booking['startDate']);
                    $user = $booking['user'];
                    $duration = $this->calculateBookingDuration($booking['startDate'], $booking['endDate']);
                    // Zähle verschiedene Nutzer im Monat
                    if (!isset($yearData[$year])) {
                        $yearData[$year] = [];
                        $yearData[$year]['users'] = [];
                        $yearData[$year]['bookings'] = 0;
                        $yearData[$year]['totalDuration'] = 0;
                    }

                    if (!isset($monthsData[$month])) {
                        $monthsData[$month] = [];
                        $monthsData[$month]['bookings'] = 0;
                        $monthsData[$month]['users'] = [];
                        $monthsData[$month]['oneDayBookings'] = 0;
                        $monthsData[$month]['twoDayBookings'] = 0;
                        $monthsData[$month]['threeDayBookings'] = 0;
                        $monthsData[$month]['fourDayBookings'] = 0;
                        $monthsData[$month]['defaultBookings'] = 0;
                        $monthsData[$month]['totalDuration'] = 0;
                    }
                    // Zähle Buchungen im Monat
                    $monthsData[$month]['bookings']++;
                    $yearData[$year]['bookings']++;

                    // Zähle verschiedene Nutzer im Monat
                    if (!in_array($user, $monthsData[$month]['users'])) {
                        $monthsData[$month]['users'][] = $user;
                    }
                    if (!in_array($user, $yearData[$year]['users'])) {
                        $yearData[$year]['users'][] = $user;
                    }
                    $monthsData[$month]['totalDuration'] += $duration;
                    $yearData[$year]['totalDuration'] += $duration;

                    // Zähle 1-Tages, 2-Tages und 3-Tages Buchungen
                    switch ($duration) {
                        case 1:
                            $monthsData[$month]['oneDayBookings']++;
                            break;
                        case 2:
                            $monthsData[$month]['twoDayBookings']++;
                            break;
                        case 3:
                            $monthsData[$month]['threeDayBookings']++;
                            break;
                        case 4:
                            $monthsData[$month]['fourDayBookings']++;
                            break;
                        default:
                            $monthsData[$month]['defaultBookings']++;
                            break;
                    }
                }
                $lastMonth = "";
                uksort($monthsData, function ($a, $b) {
                    $dateA = DateTime::createFromFormat('F Y', $a);
                    $dateB = DateTime::createFromFormat('F Y', $b);

                    if (!$dateA || !$dateB) {
                        return 0; // Invalid date format, no change in order
                    }

                    return $dateA <=> $dateB;
                });
                // Ausgabe der Daten in die Tabelle
                foreach ($monthsData as $month => $data) {
                    if (!str_contains($lastMonth, substr($month, -4))) {

                        $worksheet->setCellValue([1, $row], substr(Date::replaceEnglishMonths($month), -4));
                        $worksheet->getStyle([1, $row])->getFont()->setBold(true);
                        $worksheet->getStyle([1, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                        $worksheet->getStyle([1, $row])->getFont()->setColor($white);
                        $worksheet->getStyle([1, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                        $worksheet->getStyle([1, $row])->getFill()->setStartColor($darkgrey);
                        $worksheet->mergeCells([1, $row, 9, $row]);
                        $row++;

                        $worksheet->setCellValue([1, $row], 'verschiedene Nutzer: ' . count($yearData[substr(Date::replaceEnglishMonths($month), -4)]['users']));
                        $worksheet->getStyle([1, $row])->getFont()->setBold(true);
                        $worksheet->getStyle([1, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                        $worksheet->getStyle([1, $row])->getFont()->setColor($white);
                        $worksheet->getStyle([1, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                        $worksheet->getStyle([1, $row])->getFill()->setStartColor($darkgrey);

                        $worksheet->mergeCells([1, $row, 3, $row]);
                        $worksheet->setCellValue([4, $row], 'Gesamtbuchungen: ' . $yearData[substr(Date::replaceEnglishMonths($month), -4)]['bookings']);
                        $worksheet->getStyle([4, $row])->getFont()->setBold(true);
                        $worksheet->getStyle([4, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                        $worksheet->getStyle([4, $row])->getFont()->setColor($white);
                        $worksheet->getStyle([4, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                        $worksheet->getStyle([4, $row])->getFill()->setStartColor($darkgrey);
                        $worksheet->mergeCells([4, $row, 6, $row]);

                        $worksheet->setCellValue([7, $row], 'Gesamtdauer: ' . $yearData[substr(Date::replaceEnglishMonths($month), -4)]['totalDuration']);
                        $worksheet->getStyle([7, $row])->getFont()->setBold(true);
                        $worksheet->getStyle([7, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                        $worksheet->getStyle([7, $row])->getFont()->setColor($white);
                        $worksheet->getStyle([7, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                        $worksheet->getStyle([7, $row])->getFill()->setStartColor($darkgrey);
                        $worksheet->mergeCells([7, $row, 9, $row]);
                        $row++;

                    }
                    $lastMonth = $month;

                    $worksheet->setCellValue([1, $row], substr(Date::replaceEnglishMonths($month), 0, -5));
                    $worksheet->getStyle([1, $row])->getFont()->setBold(true);
                    $worksheet->getStyle([1, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->getStyle([1, $row])->getFont()->setColor($white);
                    $worksheet->getStyle([1, $row])->getFill()->setFillType(Fill::FILL_SOLID);
                    $worksheet->getStyle([1, $row])->getFill()->setStartColor($darkgrey);
                    $worksheet->setCellValue([2, $row], $data['bookings']);
                    $worksheet->getStyle([2, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->setCellValue([3, $row], count($data['users']));
                    $worksheet->getStyle([3, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->setCellValue([4, $row], $data['oneDayBookings']);
                    $worksheet->getStyle([4, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->setCellValue([5, $row], $data['twoDayBookings']);
                    $worksheet->getStyle([5, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->setCellValue([6, $row], $data['threeDayBookings']);
                    $worksheet->getStyle([6, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->setCellValue([7, $row], $data['fourDayBookings']);
                    $worksheet->getStyle([7, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->setCellValue([8, $row], $data['defaultBookings']);
                    $worksheet->getStyle([8, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $worksheet->setCellValue([9, $row], $data['totalDuration']);
                    $worksheet->getStyle([9, $row])->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
                    $row++;


                }
                foreach ($worksheet->getColumnIterator() as $column) {
                    $worksheet->getColumnDimension($column->getColumnIndex())->setAutoSize(true);
                }
            }


            $this->printExcel($spreadsheet);

    }


    private function printExcel($spreadsheet)
    {
        // Set headers to force the browser to download the file
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment; filename="Lastenrad-Statistik.xlsx"');
        header('Cache-Control: max-age=0');

        // Use output buffering to capture the content
        ob_start();

        // Save the spreadsheet to output buffer
        $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
        $writer->save('php://output');

        // Get the content from the output buffer
        $excelContent = ob_get_clean();

        // Output the content directly to the browser
        echo $excelContent;

        // Exit to prevent any additional output
        exit;
    }

}


/*
 * Retrieve this value with:
 * $commonbookings_additional_features_options = get_option( 'commonbookings_additional_features_option_name' ); // Array of All Options
 * $werbung_0 = $commonbookings_additional_features_options['werbung_0']; // Werbung
 */
