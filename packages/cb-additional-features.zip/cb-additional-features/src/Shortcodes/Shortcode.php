<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\Shortcodes;
use CommonsBooking\Helper\Helper;
use CommonsBooking\Repository\Booking;
use CommonsBooking\Model\Item as ItemModel;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\Log;
use CommonsBooking\Repository\Item as ItemRepo;
use CommonsBooking\Repository\Location as LocationRepo;
use CommonsBooking\Wordpress\CustomPostType\Item;
use CommonsBooking\Wordpress\CustomPostType\Timeframe;
use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\TemplateLoader;


class Shortcode
{
    public function __construct()
    {
        add_shortcode('cbaf_bookings', [$this, 'bookings']);
        add_shortcode('cbaf_sidebar', [$this, 'sidebar']);
    }


    public function bookings($atts, $content, $tag)
    {

        //Parameter für Posts
        $bookings = Booking::getForCurrentUser(true, strtotime("-23 Hours -59 Minutes -59 Seconds"));

        if ( $bookings ) {
            // Check if it is the main query and one of our custom post types
            $bookings = array_filter(
                $bookings,
                function ( $booking ) {
                    return !$booking->isCancelled() && !$booking->isPast() && intval($booking->post_author) === intval(get_current_user_id());
                }
            );
        }
        $bookingArray = [];
        foreach($bookings as $booking){

            $bookingArray[] = [
                'booking' => $booking,
                'picture' => $booking->getItem()->ID,
                'item' => $booking->getItem()->post_title,
                'location' => $booking->getLocation()->post_title,
                'startTime' => $booking->sanitizeTimeField(),
                'startDate' => date_i18n('d.m.Y', $booking->getStartDate()),
                'endDate' => $booking->getEndDate(),
                'link' => $booking->bookingLinkUrl()


            ];
        }
        $commonbookings_additional_features_options = get_option(
            'commonbookings_additional_features_option_name'
        );

        $link = get_page_link(
            $commonbookings_additional_features_options['buchung_historie_1']
        );
        return TemplateLoader::load()->render('booking.html.twig', [
            'bookings' => $bookingArray,
            'historie' => $link,
        ]);
    }

    public function sidebar($atts, $content, $tag)
    {
        $commonbookings_additional_features_options = get_option(
            'commonbookings_additional_features_option_name'
        ); // Array of All Options
        $buchung_0 = get_page_link(
            $commonbookings_additional_features_options['buchung_0']
        ); // Buchung
        $profil_1 =
            $commonbookings_additional_features_options['profil_2'] == -1
                ? get_site_url() . '/wp-admin/profile.php'
                : get_page_link(
                    $commonbookings_additional_features_options['profil_2']
                ); // Profil
		$konto_3 =  $commonbookings_additional_features_options['konto_3'] == -1
                ? false
                : get_page_link(
                    $commonbookings_additional_features_options['konto_3']
                ); // Konto
        $abmelden_2 = wp_logout_url(get_home_url()); // abmelden
        return TemplateLoader::load()->render('sidebar.html.twig', [
            'user' => is_user_logged_in() ? wp_get_current_user() : false,
            'booking' => $buchung_0,
            'profil' => $profil_1,
            'logout' => $abmelden_2,
            'konto' => $konto_3,
            'login' => get_site_url()  . '/login',
            'register' => wp_registration_url(),
            'commercial' =>
                $commonbookings_additional_features_options['werbung_0'],
        ]);
    }


}
