<?php

namespace DirkDrutschmann\CommonbookingsAdditionalFeatures\QrCode;

use DirkDrutschmann\CommonbookingsAdditionalFeatures\Helper\QrCodeSettings;

class QrCodeSender
{
    private const CHECK_PAGE_SLUG = 'check';
    private ?int $currentBookingId = null;

    public function __construct()
    {
        add_action('plugins_loaded', [$this, 'initPlugin'], 10);
    }

    public function initPlugin(): void
    {
        if (!QrCodeSettings::isEnabled()) {
            return;
        }

        if (!class_exists('CommonsBooking\\Repository\\Booking')) {
            return;
        }

        add_action('wp', [$this, 'maybeCreateCheckPage']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('transition_post_status', [$this, 'captureBookingContextFromTransition'], 10, 3);
        add_filter('commonsbooking_mail_body', [$this, 'addQrCodeToEmail'], 10, 2);
        add_shortcode('cb_qr_check', [$this, 'qrCheckShortcode']);
        add_action('commonsbooking_mail_sent', [$this, 'resetCurrentBookingContext'], 10, 2);
        add_filter('commonsbooking_template_tag', [$this, 'extractBookingIdFromTemplateTag'], 10, 1);
        add_action('init', [$this, 'handleQrImageRequest']);
    }

    public function maybeCreateCheckPage(): void
    {
        $checkPage = get_page_by_path(self::CHECK_PAGE_SLUG);

        if (!$checkPage) {
            $pageData = [
                'post_title' => __('Buchung prüfen', 'cb-additional-features'),
                'post_content' => '[cb_qr_check]',
                'post_status' => 'publish',
                'post_type' => 'page',
                'post_name' => self::CHECK_PAGE_SLUG,
                'post_author' => 1,
            ];

            $pageId = wp_insert_post($pageData);

            if ($pageId) {
                update_option('cb_qr_check_page_id', $pageId);
            }
        } else {
            if (!get_option('cb_qr_check_page_id')) {
                update_option('cb_qr_check_page_id', $checkPage->ID);
            }
        }
    }

    public function enqueueAssets(): void
    {
        if (!$this->isCheckPage()) {
            return;
        }

        $relativePath = 'assets/css/commonsbooking-qr-check.css';
        $baseDir = dirname(__DIR__, 2);
        $cssPath = $baseDir . '/' . $relativePath;
        $cssUrl = plugin_dir_url($baseDir) . $relativePath;
        $version = file_exists($cssPath) ? filemtime($cssPath) : null;

        wp_enqueue_style('cbaf-qr-check', $cssUrl, [], $version);
    }

    private function isCheckPage(): bool
    {
        if (!function_exists('is_page') || !is_page()) {
            return false;
        }

        $currentId = get_queried_object_id();
        $checkPageId = $this->getCheckPageId();

        if ($checkPageId && intval($currentId) === $checkPageId) {
            return true;
        }

        $checkPage = get_page_by_path(self::CHECK_PAGE_SLUG);
        if ($checkPage && intval($checkPage->ID) === intval($currentId)) {
            return true;
        }

        return false;
    }

    private function getCheckPageId(): ?int
    {
        $pageId = intval(get_option('cb_qr_check_page_id'));
        return $pageId > 0 ? $pageId : null;
    }

    public function captureBookingContextFromTransition($newStatus, $oldStatus, $post): void
    {
        if (!$this->isBookingPost($post)) {
            return;
        }

        if (!in_array($newStatus, ['confirmed', 'canceled'], true)) {
            return;
        }

        $this->setCurrentBookingId(intval($post->ID));
    }

    public function addQrCodeToEmail($body, $messageAction)
    {
        if ($messageAction !== 'confirmed') {
            return $body;
        }

        if (strpos($body, 'cb-qr-code-wrapper') !== false) {
            return $body;
        }

        $bookingId = $this->resolveBookingId($body);

        if (!$bookingId) {
            error_log('CB QR Code: Konnte Booking-ID nicht finden. Action: ' . $messageAction);
            return $body;
        }

        $checkUrl = $this->getCheckUrl($bookingId);
        $qrCodeHtml = $this->generateQrCodeHtml($checkUrl, $bookingId);

        $body .= '<div class="cb-qr-code-wrapper" style="margin-top: 20px; text-align: center;">';
        $body .= '<h3>' . esc_html__('Buchungsbestätigung scannen', 'cb-additional-features') . '</h3>';
        $body .= $qrCodeHtml;
        $body .= '<p style="font-size: 12px; color: #666;">' . esc_html__('Scannen Sie diesen QR-Code, um Ihre Buchung zu prüfen.', 'cb-additional-features') . '</p>';
        $body .= '</div>';

        return $body;
    }

    public function extractBookingIdFromTemplateTag($template)
    {
        if (!$this->currentBookingId) {
            $bookingId = $this->getBookingIdFromBacktrace(20);
            if ($bookingId) {
                $this->setCurrentBookingId($bookingId);
            }
        }

        return $template;
    }

    private function resolveBookingId(string $body = ''): ?int
    {
        if ($this->currentBookingId) {
            return $this->currentBookingId;
        }

        $bookingId = $this->getBookingIdFromGlobalPost();
        if ($bookingId) {
            $this->setCurrentBookingId($bookingId);
            return $bookingId;
        }

        $bookingId = $this->getBookingIdFromBacktrace();
        if ($bookingId) {
            $this->setCurrentBookingId($bookingId);
            return $bookingId;
        }

        $bookingId = $this->extractBookingIdFromBody($body);
        if ($bookingId) {
            $this->setCurrentBookingId($bookingId);
            return $bookingId;
        }

        return null;
    }

    private function getBookingIdFromGlobalPost(): ?int
    {
        global $post;
        if ($this->isBookingPost($post)) {
            return intval($post->ID);
        }

        return null;
    }

    private function isBookingPost($post): bool
    {
        if (!($post instanceof \WP_Post)) {
            return false;
        }

        return $post->post_type === $this->getBookingPostType();
    }

    private function getBookingPostType(): string
    {
        if (class_exists('\\CommonsBooking\\Wordpress\\CustomPostType\\Booking')) {
            return \CommonsBooking\Wordpress\CustomPostType\Booking::$postType;
        }

        return 'cb_booking';
    }

    private function getBookingIdFromBacktrace(int $depth = 40): ?int
    {
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, $depth);

        foreach ($backtrace as $trace) {
            if (!isset($trace['class'], $trace['object'])) {
                continue;
            }

            if (!method_exists($trace['object'], 'getPostId')) {
                continue;
            }

            if ($trace['class'] === 'CommonsBooking\\Messages\\BookingMessage' || $trace['class'] === 'CommonsBooking\\Messages\\Message') {
                $bookingId = intval($trace['object']->getPostId());
                if ($bookingId > 0) {
                    return $bookingId;
                }
            }
        }

        return null;
    }

    private function extractBookingIdFromBody(string $body): ?int
    {
        if (preg_match('/booking[#:]([0-9]+)/i', $body, $matches)) {
            return intval($matches[1]);
        }

        return null;
    }

    private function generateQrCodeHtml(string $url, int $bookingId): string
    {
        $qrSize = 200;
        $qrUrl = $this->getQrCodeImageUrl($url, $qrSize);

        $html = '<div style="text-align: center; margin: 20px 0;">';
        $html .= '<img src="' . esc_url($qrUrl) . '" alt="QR-Code" style="max-width: ' . $qrSize . 'px; height: auto; border: 2px solid #ddd; padding: 10px; background: white;" />';
        $html .= '</div>';

        return $html;
    }

    private function getQrCodeImageUrl(string $data, int $size = 200): string
    {
        $encodedData = urlencode($data);
        return "https://api.qrserver.com/v1/create-qr-code/?size={$size}x{$size}&data={$encodedData}";
    }

    private function getCheckUrl(int $bookingId): string
    {
        $checkPageId = get_option('cb_qr_check_page_id');

        if ($checkPageId) {
            $checkUrl = get_permalink($checkPageId);
        } else {
            $checkUrl = home_url('/' . self::CHECK_PAGE_SLUG . '/');
        }

        $token = $this->generateBookingToken($bookingId);

        return add_query_arg([
            'booking' => $bookingId,
            'token' => $token,
        ], $checkUrl);
    }

    private function generateBookingToken(int $bookingId): string
    {
        $secret = get_option('cb_qr_secret_key', wp_generate_password(32, false));
        if (!get_option('cb_qr_secret_key')) {
            update_option('cb_qr_secret_key', $secret);
        }

        return hash_hmac('sha256', $bookingId, $secret);
    }

    private function validateBookingToken(int $bookingId, string $token): bool
    {
        $expectedToken = $this->generateBookingToken($bookingId);
        return hash_equals($expectedToken, $token);
    }

    public function qrCheckShortcode($atts, $content = null, $tag = ''): string
    {
        $bookingId = isset($_GET['booking']) ? intval($_GET['booking']) : 0;
        $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';

        if (!$bookingId || !$token) {
            return $this->renderInvalidBooking();
        }

        if (!$this->validateBookingToken($bookingId, $token)) {
            return $this->renderInvalidBooking();
        }

        try {
            $booking = \CommonsBooking\Repository\Booking::getPostById($bookingId);

            if (!$booking) {
                return $this->renderInvalidBooking();
            }

            $status = $booking->getPost()->post_status;
            $isValid = ($status === 'confirmed' || $status === 'unconfirmed');

            $hasAdminAccess = false;
            if (is_user_logged_in()) {
                $currentUserId = get_current_user_id();
                $hasAdminAccess = $this->userHasBookingAccess($currentUserId, $booking);
            }

            if ($hasAdminAccess) {
                return $this->renderAdminView($booking, $isValid);
            }

            return $this->renderPublicView($booking, $isValid);
        } catch (\Throwable $e) {
            return $this->renderInvalidBooking();
        }
    }

    private function userHasBookingAccess(int $userId, $booking): bool
    {
        if (current_user_can('manage_options')) {
            return true;
        }

        $locationId = $booking->getMetaInt('location-id');
        if ($locationId) {
            $locationAdmins = get_post_meta($locationId, '_cb_location_admins', true);

            if (is_string($locationAdmins)) {
                $locationAdmins = strlen($locationAdmins) > 0 ? [$locationAdmins] : [];
            }

            if (is_array($locationAdmins) && in_array($userId, $locationAdmins, true)) {
                return true;
            }

            $locationAuthor = get_post_field('post_author', $locationId);
            if ($locationAuthor == $userId) {
                return true;
            }
        }

        $itemId = $booking->getMetaInt('item-id');
        if ($itemId) {
            $itemAdmins = get_post_meta($itemId, '_cb_item_admins', true);

            if (is_string($itemAdmins)) {
                $itemAdmins = strlen($itemAdmins) > 0 ? [$itemAdmins] : [];
            }

            if (is_array($itemAdmins) && in_array($userId, $itemAdmins, true)) {
                return true;
            }

            $itemAuthor = get_post_field('post_author', $itemId);
            if ($itemAuthor == $userId) {
                return true;
            }
        }

        return false;
    }

    private function renderPublicView($booking, bool $isValid): string
    {
        $item = $booking->getItem();
        $location = $booking->getLocation();
        $startDate = date_i18n('d.m.Y H:i', $booking->getStartDate());
        $endDate = date_i18n('d.m.Y H:i', $booking->getEndDate());
        $statusClass = $isValid ? 'cb-qr-status--valid' : 'cb-qr-status--invalid';

        ob_start();
        ?>
        <div class="cb-qr-check-container">
            <div class="cb-qr-status <?php echo esc_attr($statusClass); ?>">
                <?php echo $isValid ? __('Buchung valide', 'cb-additional-features') : __('Buchung invalide', 'cb-additional-features'); ?>
            </div>
            <p class="cb-qr-description">
                <?php
                if ($isValid) {
                    _e('Diese Buchung ist gültig.', 'cb-additional-features');
                } else {
                    _e('Diese Buchung ist nicht mehr gültig oder wurde storniert.', 'cb-additional-features');
                }
                ?>
            </p>

            <div class="cb-qr-booking-info">
                <h3 class="cb-qr-section-title"><?php _e('Buchungsinformationen', 'cb-additional-features'); ?></h3>

                <div class="cb-qr-booking-info-row">
                    <span class="cb-qr-label"><?php _e('Artikel:', 'cb-additional-features'); ?></span>
                    <span class="cb-qr-value"><?php echo esc_html($item->post_title); ?></span>
                </div>

                <div class="cb-qr-booking-info-row">
                    <span class="cb-qr-label"><?php _e('Standort:', 'cb-additional-features'); ?></span>
                    <span class="cb-qr-value"><?php echo esc_html($location->post_title); ?></span>
                </div>

                <div class="cb-qr-booking-info-row">
                    <span class="cb-qr-label"><?php _e('Von:', 'cb-additional-features'); ?></span>
                    <span class="cb-qr-value"><?php echo esc_html($startDate); ?></span>
                </div>

                <div class="cb-qr-booking-info-row">
                    <span class="cb-qr-label"><?php _e('Bis:', 'cb-additional-features'); ?></span>
                    <span class="cb-qr-value"><?php echo esc_html($endDate); ?></span>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function getFormattedUserInfo($booking): string
    {
        if (!function_exists('commonsbooking_parse_template') || !class_exists('\\CommonsBooking\\Settings\\Settings')) {
            return '';
        }

        $template = \CommonsBooking\Settings\Settings::getOption('commonsbooking_options_templates', 'user_details_template');
        if (!$template) {
            return '';
        }

        $objects = [
            'booking' => $booking,
            'item' => $booking->getItem(),
            'location' => $booking->getLocation(),
            'user' => $booking->getUserData(),
        ];

        try {
            return commonsbooking_parse_template($template, $objects);
        } catch (\Throwable $e) {
            return '';
        }
    }

    private function renderAdminView($booking, bool $isValid): string
    {
        $status = $booking->getPost()->post_status;
        $isCanceled = ($status === 'canceled');
        $statusClass = $isCanceled ? 'cb-qr-status--canceled' : 'cb-qr-status--valid';

        $userData = $booking->getUserData();
        $item = $booking->getItem();
        $location = $booking->getLocation();

        $startDate = date_i18n('d.m.Y H:i', $booking->getStartDate());
        $endDate = date_i18n('d.m.Y H:i', $booking->getEndDate());
        $pickupDatetime = $booking->pickupDatetime();
        $returnDatetime = $booking->returnDatetime();
        $bookingCode = $booking->getBookingCode();
        $locationAddress = method_exists($location, 'formattedAddressOneLine') ? $location->formattedAddressOneLine() : '';
        $locationPickupInstructions = method_exists($location, 'formattedPickupInstructionsOneLine') ? $location->formattedPickupInstructionsOneLine() : '';
        $locationContact = method_exists($location, 'formattedContactInfoOneLine') ? $location->formattedContactInfoOneLine() : '';
        $formattedUserInfo = $this->getFormattedUserInfo($booking);
        $bookingComment = $booking->returnComment();
        $internalComment = commonsbooking_sanitizeHTML($booking->getMeta('internal-comment'));
        $adminBookingId = $booking->getMeta('admin_booking_id');
        $adminBookingUser = $adminBookingId ? get_user_by('ID', $adminBookingId) : null;
        $adminBookingDisplay = '';
        if ($adminBookingUser instanceof \WP_User) {
            $adminBookingDisplay = sprintf(
                '%s (%s %s)',
                $adminBookingUser->user_login,
                $adminBookingUser->first_name,
                $adminBookingUser->last_name
            );
        }

        ob_start();
        ?>
        <div class="cb-qr-check-admin-container">
            <div class="cb-qr-status-header <?php echo esc_attr($statusClass); ?>">
                <?php echo $isCanceled ? __('STORNIERT', 'cb-additional-features') : __('VALIDE', 'cb-additional-features'); ?>
            </div>

            <div class="cb-qr-booking-details">
                <h2 class="cb-qr-section-title"><?php _e('Buchungsdetails', 'cb-additional-features'); ?></h2>

                <div class="cb-qr-table-wrapper">
                    <table class="cb-qr-booking-table">
                        <tbody>
                        <tr>
                            <th scope="row"><?php _e('Buchungs-ID:', 'cb-additional-features'); ?></th>
                            <td>#<?php echo esc_html($booking->ID); ?></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Status:', 'cb-additional-features'); ?></th>
                            <td><?php echo esc_html(ucfirst($status)); ?></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Nutzer:', 'cb-additional-features'); ?></th>
                            <td>
                                <?php echo esc_html($userData->display_name); ?><br>
                                <small><?php echo esc_html($userData->user_email); ?></small>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Artikel:', 'cb-additional-features'); ?></th>
                            <td><?php echo esc_html($item->post_title); ?></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Standort:', 'cb-additional-features'); ?></th>
                            <td><?php echo esc_html($location->post_title); ?></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Von:', 'cb-additional-features'); ?></th>
                            <td><?php echo esc_html($startDate); ?></td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Bis:', 'cb-additional-features'); ?></th>
                            <td><?php echo esc_html($endDate); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="cb-qr-card-grid">
                <div class="cb-qr-card">
                    <h3 class="cb-qr-section-title"><?php _e('Zeitraum & Zugang', 'cb-additional-features'); ?></h3>
                    <div class="cb-qr-card-row">
                        <span class="cb-qr-label"><?php _e('Abholung', 'cb-additional-features'); ?></span>
                        <span class="cb-qr-value"><?php echo esc_html($pickupDatetime); ?></span>
                    </div>
                    <div class="cb-qr-card-row">
                        <span class="cb-qr-label"><?php _e('Rückgabe', 'cb-additional-features'); ?></span>
                        <span class="cb-qr-value"><?php echo esc_html($returnDatetime); ?></span>
                    </div>
                    <?php if ($bookingCode) : ?>
                        <div class="cb-qr-card-row">
                            <span class="cb-qr-label"><?php _e('Buchungscode', 'cb-additional-features'); ?></span>
                            <span class="cb-qr-value"><strong><?php echo esc_html($bookingCode); ?></strong></span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="cb-qr-card">
                    <h3 class="cb-qr-section-title"><?php _e('Standortinformationen', 'cb-additional-features'); ?></h3>
                    <?php if (!empty($locationAddress)) : ?>
                        <div class="cb-qr-card-row">
                            <span class="cb-qr-label"><?php _e('Adresse', 'cb-additional-features'); ?></span>
                            <span class="cb-qr-value"><?php echo commonsbooking_sanitizeHTML($locationAddress); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($locationPickupInstructions)) : ?>
                        <div class="cb-qr-card-row">
                            <span class="cb-qr-label"><?php _e('Abholhinweise', 'cb-additional-features'); ?></span>
                            <span class="cb-qr-value"><?php echo commonsbooking_sanitizeHTML($locationPickupInstructions); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($locationContact)) : ?>
                        <div class="cb-qr-card-row">
                            <span class="cb-qr-label"><?php _e('Kontakt', 'cb-additional-features'); ?></span>
                            <span class="cb-qr-value"><?php echo commonsbooking_sanitizeHTML($locationContact); ?></span>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="cb-qr-card">
                    <h3 class="cb-qr-section-title"><?php _e('Nutzerinformationen', 'cb-additional-features'); ?></h3>
                    <div class="cb-qr-card-row">
                        <span class="cb-qr-label"><?php _e('Name', 'cb-additional-features'); ?></span>
                        <span class="cb-qr-value"><?php echo esc_html($userData->first_name . ' ' . $userData->last_name); ?></span>
                    </div>
                    <div class="cb-qr-card-row">
                        <span class="cb-qr-label"><?php _e('E-Mail', 'cb-additional-features'); ?></span>
                        <span class="cb-qr-value"><?php echo esc_html($userData->user_email); ?></span>
                    </div>
                    <div class="cb-qr-card-row">
                        <span class="cb-qr-label"><?php _e('Benutzername', 'cb-additional-features'); ?></span>
                        <span class="cb-qr-value"><?php echo esc_html($userData->user_login); ?></span>
                    </div>
                    <?php if (!empty($formattedUserInfo)) : ?>
                        <div class="cb-qr-card-row">
                            <span class="cb-qr-label"><?php _e('Profilangaben', 'cb-additional-features'); ?></span>
                            <span class="cb-qr-value cb-qr-value--multiline"><?php echo commonsbooking_sanitizeHTML($formattedUserInfo); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($adminBookingDisplay)) : ?>
                        <div class="cb-qr-card-row">
                            <span class="cb-qr-label"><?php _e('Erstellt durch', 'cb-additional-features'); ?></span>
                            <span class="cb-qr-value"><?php echo esc_html($adminBookingDisplay); ?></span>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if (!empty($bookingComment) || !empty($internalComment)) : ?>
                    <div class="cb-qr-card">
                        <h3 class="cb-qr-section-title"><?php _e('Kommentare', 'cb-additional-features'); ?></h3>
                        <?php if (!empty($bookingComment)) : ?>
                            <div class="cb-qr-card-row cb-qr-card-row--stacked">
                                <span class="cb-qr-label"><?php _e('Nutzerhinweis', 'cb-additional-features'); ?></span>
                                <span class="cb-qr-value cb-qr-value--multiline"><?php echo wp_kses_post(nl2br($bookingComment)); ?></span>
                            </div>
                        <?php endif; ?>
                        <?php if (!empty($internalComment)) : ?>
                            <div class="cb-qr-card-row cb-qr-card-row--stacked">
                                <span class="cb-qr-label"><?php _e('Interner Kommentar', 'cb-additional-features'); ?></span>
                                <span class="cb-qr-value cb-qr-value--multiline"><?php echo wp_kses_post(nl2br($internalComment)); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    private function renderInvalidBooking(): string
    {
        ob_start();
        ?>
        <div class="cb-qr-check-container">
            <div class="cb-qr-status cb-qr-status--invalid">
                <?php _e('Buchung invalide', 'cb-additional-features'); ?>
            </div>
            <p class="cb-qr-description">
                <?php _e('Diese Buchung konnte nicht gefunden werden oder der Link ist ungültig.', 'cb-additional-features'); ?>
            </p>
        </div>
        <?php
        return ob_get_clean();
    }

    public function resetCurrentBookingContext($action = null, $result = null): void
    {
        $this->clearCurrentBookingId();
    }

    public function handleQrImageRequest(): void
    {
        // Placeholder for local QR-code generation.
    }

    private function setCurrentBookingId(int $bookingId): void
    {
        if ($bookingId <= 0) {
            return;
        }

        $this->currentBookingId = $bookingId;
    }

    private function clearCurrentBookingId(): void
    {
        $this->currentBookingId = null;
    }
}
